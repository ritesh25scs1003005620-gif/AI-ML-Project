Business Requirement Document (BRD)

Project Title: Smart Classroom & Timetable Scheduler
Tech Stack: PHP (backend, web app) + MySQL (database)

1. Introduction
1.1 Purpose

The purpose of this project is to develop a web-based timetable scheduling system for higher education institutions. The system will generate optimized timetables for classrooms, labs, students, and faculty by considering multiple constraints like room capacity, number of subjects, faculty availability, and workload distribution.

1.2 Background

Currently, most institutions use manual spreadsheets or basic tools to create timetables. This causes:

Frequent clashes in classes

Uneven workload on teachers

Underutilized classrooms

Difficulty managing electives & multidisciplinary courses

With NEP 2020 encouraging flexible and multidisciplinary learning, scheduling is becoming even more complex. An intelligent timetable generator is needed.

1.3 Objectives

Automate timetable generation using predefined rules and constraints.

Ensure optimal usage of classrooms and faculty.

Provide multiple timetable options for admin approval.

Allow real-time updates and rearrangements when changes happen.

2. Scope of the System
2.1 In Scope

Login for authorized staff (Admin, Faculty Coordinators).

Input of all timetable parameters (subjects, faculty, classrooms, etc.).

Auto-generation of optimized timetables.

Ability to view, approve, or modify suggested timetables.

Handling special classes with fixed slots.

Multi-department & multi-shift support.

2.2 Out of Scope

Student self-login (Phase 1 will only be admin-driven).

Mobile application (only web version in this phase).

AI/ML-based predictions (only rule-based optimization for now).

3. Users & Roles

Administrator

Add/update classrooms, subjects, faculty, student batches.

Generate timetable options.

Approve final timetable.

Faculty Coordinator / HOD

Suggest faculty availability.

Review timetable drafts.

System

Auto-generate optimized timetables.

Provide rearrangement suggestions.

4. Functional Requirements

Login Module

Role-based login (Admin, HOD).

Secure access with username/password.

Input Data Module

Add/edit classrooms (capacity, type: classroom/lab).

Add/edit subjects (name, code, weekly hours).

Add/edit faculty (availability, max load, leaves/month).

Add/edit student batches (size, semester, electives).

Timetable Generation Module

Generate optimized timetable based on rules.

Show multiple timetable options.

Highlight conflicts if no perfect solution exists.

Approval & Modification

Admin can approve a timetable.

Admin can manually adjust slots.

System provides suggestions for rearrangements.

Reports/Export

View timetable department-wise / faculty-wise / classroom-wise.

Export timetable as PDF/Excel.

5. Non-Functional Requirements

Usability: Simple UI, minimal clicks, clean layout.

Performance: Generate timetable within few seconds for a semester.

Scalability: Should support at least 2000 students, 100 faculty, 100 classrooms.

Security: Only authorized personnel can log in.

Compatibility: Runs in browser (desktop & mobile responsive).

6. Database (MySQL)
Main Tables

Users – login credentials, role.

Classrooms – room details, capacity, type.

Subjects – subject info, weekly hours.

Faculty – faculty info, availability, workload.

Batches – student batch info.

Timetable – generated timetable entries.

7. Tech Stack

Frontend: HTML, CSS, JavaScript (basic, minimal UI)

Backend: core PHP 

Database: MySQL

Server: Apache (XAMPP/WAMP for dev, LAMP stack for prod)

8. Deliverables

Web-based timetable scheduling system.

Admin dashboard for timetable management.

Database schema (MySQL).

Documentation (user guide + technical setup).

9. Future Enhancements

Mobile app (Android/iOS).

AI-based smart conflict resolution.

Faculty & student portals.

Integration with LMS (Learning Management Systems).

