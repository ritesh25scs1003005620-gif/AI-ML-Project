-- Enhanced Sample Data for Smart Classroom & Timetable Scheduler
-- This provides enough subjects to fill 6 classes per day for each batch

-- Clear existing mappings
DELETE FROM batch_subject_faculty;

-- Enhanced Subject-Faculty Mappings with more realistic weekly hours
-- Each batch needs 36 hours per week (6 classes × 6 days)

-- CS-2024-A (Batch ID 1) - Semester 3
INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES
(1, 1, 1, 6), -- Programming Fundamentals - Dr. John Smith (6 hours)
(1, 6, 3, 6), -- Discrete Mathematics - Dr. Michael Brown (6 hours)
(1, 8, 6, 4), -- Technical Communication - Prof. Lisa Anderson (4 hours)
(1, 9, 5, 4), -- Physics Lab - Dr. Robert Wilson (4 hours)
(1, 2, 2, 8), -- Data Structures - Prof. Sarah Johnson (8 hours)
(1, 3, 4, 8); -- Database Management Systems - Prof. Emily Davis (8 hours)
-- Total: 36 hours per week

-- CS-2024-B (Batch ID 2) - Semester 3
INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES
(2, 1, 2, 6), -- Programming Fundamentals - Prof. Sarah Johnson (6 hours)
(2, 6, 3, 6), -- Discrete Mathematics - Dr. Michael Brown (6 hours)
(2, 8, 6, 4), -- Technical Communication - Prof. Lisa Anderson (4 hours)
(2, 2, 1, 8), -- Data Structures - Dr. John Smith (8 hours)
(2, 3, 4, 8), -- Database Management Systems - Prof. Emily Davis (8 hours)
(2, 4, 5, 4); -- Computer Networks - Dr. Robert Wilson (4 hours)
-- Total: 36 hours per week

-- CS-2023-A (Batch ID 3) - Semester 5
INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES
(3, 2, 1, 8), -- Data Structures - Dr. John Smith (8 hours)
(3, 3, 4, 8), -- Database Management Systems - Prof. Emily Davis (8 hours)
(3, 4, 5, 6), -- Computer Networks - Dr. Robert Wilson (6 hours)
(3, 5, 2, 6), -- Operating Systems - Prof. Sarah Johnson (6 hours)
(3, 7, 3, 4), -- Linear Algebra - Dr. Michael Brown (4 hours)
(3, 1, 6, 4); -- Programming Fundamentals Advanced - Prof. Lisa Anderson (4 hours)
-- Total: 36 hours per week

-- CS-2023-B (Batch ID 4) - Semester 5  
INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES
(4, 2, 2, 8), -- Data Structures - Prof. Sarah Johnson (8 hours)
(4, 3, 4, 8), -- Database Management Systems - Prof. Emily Davis (8 hours)
(4, 4, 1, 6), -- Computer Networks - Dr. John Smith (6 hours)
(4, 5, 5, 6), -- Operating Systems - Dr. Robert Wilson (6 hours)
(4, 7, 3, 4), -- Linear Algebra - Dr. Michael Brown (4 hours)
(4, 6, 6, 4); -- Discrete Mathematics Advanced - Prof. Lisa Anderson (4 hours)
-- Total: 36 hours per week

-- IT-2024-A (Batch ID 5) - Semester 3
INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES
(5, 1, 4, 8), -- Programming Fundamentals - Prof. Emily Davis (8 hours)
(5, 6, 3, 6), -- Discrete Mathematics - Dr. Michael Brown (6 hours)
(5, 8, 6, 4), -- Technical Communication - Prof. Lisa Anderson (4 hours)
(5, 2, 1, 8), -- Data Structures - Dr. John Smith (8 hours)
(5, 9, 5, 6), -- Physics Lab - Dr. Robert Wilson (6 hours)
(5, 3, 2, 4); -- Database Management Systems - Prof. Sarah Johnson (4 hours)
-- Total: 36 hours per week

-- Verify the data
SELECT 
    b.batch_code,
    SUM(bsf.weekly_hours) as total_weekly_hours,
    COUNT(bsf.id) as subject_count
FROM batch_subject_faculty bsf
JOIN batches b ON bsf.batch_id = b.id
GROUP BY b.id, b.batch_code
ORDER BY b.batch_code; 