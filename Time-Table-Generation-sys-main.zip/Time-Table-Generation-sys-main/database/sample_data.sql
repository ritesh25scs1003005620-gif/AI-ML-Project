-- Sample Data for Smart Classroom & Timetable Scheduler
-- Run this after importing schema.sql to populate with test data

-- Sample Classrooms
INSERT INTO classrooms (room_code, capacity, room_type) VALUES
('A101', 60, 'classroom'),
('A102', 45, 'classroom'),
('A103', 50, 'classroom'),
('LAB-CS1', 30, 'lab'),
('LAB-CS2', 30, 'lab'),
('B201', 80, 'classroom'),
('B202', 40, 'classroom'),
('LAB-PHY', 25, 'lab');

-- Sample Subjects
INSERT INTO subjects (subject_code, subject_name, weekly_hours) VALUES
('CS101', 'Programming Fundamentals', 4),
('CS102', 'Data Structures', 3),
('CS103', 'Database Management Systems', 3),
('CS104', 'Computer Networks', 3),
('CS105', 'Operating Systems', 3),
('MATH101', 'Discrete Mathematics', 3),
('MATH102', 'Linear Algebra', 3),
('ENG101', 'Technical Communication', 2),
('PHY101', 'Physics Lab', 2);

-- Sample Faculty with availability (Mon-Fri, periods 1-8)
INSERT INTO faculty (faculty_code, full_name, max_weekly_load, availability_json) VALUES
('FAC001', 'Dr. John Smith', 16, '{"Mon":[1,2,3,4,5,6],"Tue":[1,2,3,4,5,6],"Wed":[1,2,3,4,5,6],"Thu":[1,2,3,4,5,6],"Fri":[1,2,3,4,5,6]}'),
('FAC002', 'Prof. Sarah Johnson', 14, '{"Mon":[2,3,4,5,6,7],"Tue":[1,2,3,4,5,6],"Wed":[1,2,3,4,5,6],"Thu":[1,2,3,4,5,6],"Fri":[1,2,3,4,5]}'),
('FAC003', 'Dr. Michael Brown', 12, '{"Mon":[1,2,3,4],"Tue":[1,2,3,4,5,6],"Wed":[2,3,4,5,6],"Thu":[1,2,3,4,5],"Fri":[1,2,3,4,5,6]}'),
('FAC004', 'Prof. Emily Davis', 15, '{"Mon":[1,2,3,4,5,6,7],"Tue":[1,2,3,4,5],"Wed":[1,2,3,4,5,6],"Thu":[2,3,4,5,6,7],"Fri":[1,2,3,4]}'),
('FAC005', 'Dr. Robert Wilson', 13, '{"Mon":[3,4,5,6,7],"Tue":[1,2,3,4,5,6,7],"Wed":[1,2,3,4],"Thu":[1,2,3,4,5,6],"Fri":[2,3,4,5,6]}'),
('FAC006', 'Prof. Lisa Anderson', 12, '{"Mon":[1,2,3,4,5],"Tue":[2,3,4,5,6,7],"Wed":[1,2,3,4,5,6,7],"Thu":[1,2,3,4],"Fri":[1,2,3,4,5,6]}');

-- Sample Student Batches
INSERT INTO batches (batch_code, semester, size) VALUES
('CS-2024-A', 3, 45),
('CS-2024-B', 3, 42),
('CS-2023-A', 5, 38),
('CS-2023-B', 5, 40),
('IT-2024-A', 3, 35);

-- Sample Subject-Faculty Mappings
INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES
-- CS-2024-A (Batch ID 1)
(1, 1, 1, 4), -- Programming Fundamentals - Dr. John Smith
(1, 6, 3, 3), -- Discrete Mathematics - Dr. Michael Brown
(1, 8, 6, 2), -- Technical Communication - Prof. Lisa Anderson
(1, 9, 5, 2), -- Physics Lab - Dr. Robert Wilson

-- CS-2024-B (Batch ID 2)
(2, 1, 2, 4), -- Programming Fundamentals - Prof. Sarah Johnson
(2, 6, 3, 3), -- Discrete Mathematics - Dr. Michael Brown
(2, 8, 6, 2), -- Technical Communication - Prof. Lisa Anderson

-- CS-2023-A (Batch ID 3)
(3, 2, 1, 3), -- Data Structures - Dr. John Smith
(3, 3, 4, 3), -- Database Management Systems - Prof. Emily Davis
(3, 4, 5, 3), -- Computer Networks - Dr. Robert Wilson
(3, 5, 2, 3), -- Operating Systems - Prof. Sarah Johnson
(3, 7, 3, 3), -- Linear Algebra - Dr. Michael Brown

-- CS-2023-B (Batch ID 4)
(4, 2, 2, 3), -- Data Structures - Prof. Sarah Johnson
(4, 3, 4, 3), -- Database Management Systems - Prof. Emily Davis
(4, 4, 1, 3), -- Computer Networks - Dr. John Smith
(4, 5, 5, 3), -- Operating Systems - Dr. Robert Wilson

-- IT-2024-A (Batch ID 5)
(5, 1, 4, 4), -- Programming Fundamentals - Prof. Emily Davis
(5, 6, 3, 3), -- Discrete Mathematics - Dr. Michael Brown
(5, 8, 6, 2); -- Technical Communication - Prof. Lisa Anderson 