# Smart Classroom & Timetable Scheduler

## Overview
A comprehensive web-based timetable scheduling system for higher education institutions. Built with PHP (core) and MySQL, featuring automated timetable generation with conflict resolution.

## Features
✅ **Complete CRUD Operations**
- Classroom Management (capacity, type: classroom/lab)
- Subject Management (weekly hours, codes)
- Faculty Management (availability, workload limits)
- Student Batch Management
- Subject-Faculty Mapping

✅ **Intelligent Timetable Generation**
- Automated scheduling algorithm
- Conflict detection and resolution
- Faculty availability constraints
- Classroom capacity optimization
- Workload distribution

✅ **Multiple View Options**
- Complete timetable overview
- Batch-wise timetables
- Faculty-wise schedules
- Classroom utilization

✅ **Export & Reports**
- CSV export functionality
- Responsive web design
- Modern UI with clean interface

## Requirements
- PHP 8.1+
- MySQL 8+
- Apache (XAMPP/WAMP on Windows, LAMP on Linux)
- Modern web browser

## Quick Setup (XAMPP/WAMP)

### 1. Installation
1. Clone or copy this folder into your web root:
   ```
   C:\xampp\htdocs\smart-timetable
   ```
   or
   ```
   E:\Ritesh\smart-timetable
   ```

### 2. Database Setup
1. Create a MySQL database named `smart_timetable`
2. Import the schema:
   - Open `phpMyAdmin` → your database → Import
   - Choose `database/schema.sql` → Go
3. (Optional) Import sample data:
   - Import `database/sample_data.sql` for testing

### 3. Configuration
1. Edit `app/config.php` and update database credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'smart_timetable');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

### 4. Launch
1. Start Apache and MySQL services
2. Visit: `http://localhost/smart-timetable/public/`
3. Login with default credentials:
   - **Email:** `admin@local`
   - **Password:** `admin123`

## Usage Guide

### 1. Initial Setup
1. **Add Classrooms** - Define available rooms with capacity and type
2. **Add Subjects** - Create subjects with weekly hour requirements
3. **Add Faculty** - Register faculty with availability schedules
4. **Add Batches** - Create student batches with semester info
5. **Create Mappings** - Assign subjects to faculty for specific batches

### 2. Timetable Generation
1. Navigate to **Timetable** section
2. Click **Generate Timetable** to auto-create schedules
3. View results by:
   - All classes (complete overview)
   - Specific batch
   - Faculty member
   - Classroom
4. Export to CSV for external use

### 3. Management Features
- **Edit/Delete** any entity through respective management pages
- **Real-time conflict detection** during mapping creation
- **Workload tracking** for faculty members
- **Responsive design** for mobile and desktop use

## Project Structure
```
public/            # Web entry point
├── index.php      # Main router

app/               # Backend logic
├── auth.php       # Authentication system
├── config.php     # Database configuration
├── db.php         # Database helpers
├── layout.php     # HTML layout & CSS
├── routes.php     # Route handler
├── subjects.php   # Subject management
├── classrooms.php # Classroom management
├── faculty.php    # Faculty management
├── batches.php    # Batch management
├── mapping.php    # Subject-faculty mapping
└── timetable.php  # Timetable generation

views/             # Frontend templates
├── dashboard.php  # Main dashboard
├── login.php      # Login form
├── subjects.php   # Subject CRUD interface
├── classrooms.php # Classroom CRUD interface
├── faculty.php    # Faculty CRUD interface
├── batches.php    # Batch CRUD interface
├── mapping.php    # Mapping CRUD interface
└── timetable.php  # Timetable display & generation

database/          # Database files
├── schema.sql     # Database structure
└── sample_data.sql # Test data
```

## Algorithm Details

The timetable generation uses a constraint-based scheduling algorithm:

1. **Constraint Checking:**
   - Faculty availability (day/period)
   - Classroom availability
   - Batch scheduling conflicts
   - Faculty workload limits

2. **Optimization Strategy:**
   - Prioritizes larger classrooms for bigger batches
   - Distributes workload evenly across faculty
   - Minimizes scheduling conflicts

3. **Conflict Resolution:**
   - Reports unscheduled classes
   - Suggests alternative arrangements
   - Maintains data integrity

## Customization

### Adding New Constraints
Edit `app/timetable.php` to add custom scheduling rules:
```php
function custom_constraint_check($batch_id, $faculty_id, $day, $period) {
    // Add your custom logic here
    return true; // or false to block scheduling
}
```

### UI Modifications
Update `app/layout.php` for styling changes or add custom CSS.

### Database Extensions
Modify `database/schema.sql` to add new fields or tables, then update corresponding PHP models.

## Production Deployment

1. **Security:**
   - Change default admin password
   - Set `DISPLAY_ERRORS` to `false` in `app/config.php`
   - Use strong database credentials
   - Enable HTTPS

2. **Performance:**
   - Configure proper Apache virtual host
   - Enable PHP OPcache
   - Set up database indexing
   - Implement caching if needed

3. **Backup:**
   - Regular database backups
   - File system backups
   - Export functionality for data portability

## Troubleshooting

**Database Connection Issues:**
- Verify MySQL service is running
- Check credentials in `app/config.php`
- Ensure database exists and schema is imported

**Permission Errors:**
- Check web server write permissions
- Verify PHP error logs
- Enable error display for debugging

**Scheduling Conflicts:**
- Review faculty availability settings
- Check for duplicate mappings
- Verify classroom capacity vs batch size

## Future Enhancements

- **Mobile App** (Android/iOS)
- **AI-based optimization** for complex scheduling
- **Student portal** for viewing schedules
- **LMS integration** capabilities
- **Multi-semester planning**
- **Resource booking system**

## Support

For issues, feature requests, or contributions, please refer to the project documentation or contact the development team.

---

**Built with ❤️ for educational institutions seeking efficient timetable management.** 