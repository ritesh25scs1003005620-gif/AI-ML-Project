<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/classrooms.php';

$action = $_GET['action'] ?? 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $room_code = trim($_POST['room_code'] ?? '');
        $capacity = (int)($_POST['capacity'] ?? 0);
        $room_type = $_POST['room_type'] ?? 'classroom';
        
        if ($room_code && $capacity > 0 && in_array($room_type, ['classroom', 'lab'])) {
            if (create_classroom($room_code, $capacity, $room_type)) {
                $message = 'Classroom created successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to create classroom. Room code might already exist.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'edit' && $id > 0) {
        $room_code = trim($_POST['room_code'] ?? '');
        $capacity = (int)($_POST['capacity'] ?? 0);
        $room_type = $_POST['room_type'] ?? 'classroom';
        
        if ($room_code && $capacity > 0 && in_array($room_type, ['classroom', 'lab'])) {
            if (update_classroom($id, $room_code, $capacity, $room_type)) {
                $message = 'Classroom updated successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to update classroom.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'delete' && $id > 0) {
        if (delete_classroom($id)) {
            $message = 'Classroom deleted successfully!';
        } else {
            $error = 'Failed to delete classroom.';
        }
        $action = 'list';
    }
}

$base = BASE_URL;
?>

<div class="card">
    <h1>Manage Classrooms</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if ($action === 'list'): ?>
        <div style="margin-bottom: 20px;">
            <a href="<?= htmlspecialchars($base) ?>/?page=classrooms&action=create" class="btn">Add New Classroom</a>
            <a href="<?= htmlspecialchars($base) ?>/?page=dashboard" class="btn secondary">Back to Dashboard</a>
        </div>
        
        <?php
        $classrooms = get_classrooms();
        if (empty($classrooms)):
        ?>
            <p>No classrooms found. <a href="<?= htmlspecialchars($base) ?>/?page=classrooms&action=create">Add the first classroom</a>.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Room Code</th>
                        <th>Capacity</th>
                        <th>Type</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($classrooms as $classroom): ?>
                        <tr>
                            <td><?= htmlspecialchars($classroom['room_code']) ?></td>
                            <td><?= htmlspecialchars((string)$classroom['capacity']) ?></td>
                            <td><?= htmlspecialchars(ucfirst($classroom['room_type'])) ?></td>
                            <td>
                                <a href="<?= htmlspecialchars($base) ?>/?page=classrooms&action=edit&id=<?= $classroom['id'] ?>" class="btn small">Edit</a>
                                <a href="<?= htmlspecialchars($base) ?>/?page=classrooms&action=delete&id=<?= $classroom['id'] ?>" 
                                   class="btn small danger" 
                                   onclick="return confirm('Are you sure you want to delete this classroom?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
    <?php elseif ($action === 'create'): ?>
        <h2>Add New Classroom</h2>
        <form method="POST">
            <div class="form-group">
                <label for="room_code">Room Code:</label>
                <input type="text" id="room_code" name="room_code" required maxlength="50" placeholder="e.g., A101, LAB-CS1">
            </div>
            
            <div class="form-group">
                <label for="capacity">Capacity:</label>
                <input type="number" id="capacity" name="capacity" required min="1" max="500" placeholder="Number of students">
            </div>
            
            <div class="form-group">
                <label for="room_type">Room Type:</label>
                <select id="room_type" name="room_type" required>
                    <option value="classroom">Classroom</option>
                    <option value="lab">Laboratory</option>
                </select>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn">Create Classroom</button>
                <a href="<?= htmlspecialchars($base) ?>/?page=classrooms" class="btn secondary">Cancel</a>
            </div>
        </form>
        
    <?php elseif ($action === 'edit' && $id > 0): ?>
        <?php
        $classroom = get_classroom($id);
        if (!$classroom):
        ?>
            <p>Classroom not found.</p>
            <a href="<?= htmlspecialchars($base) ?>/?page=classrooms" class="btn">Back to Classrooms</a>
        <?php else: ?>
            <h2>Edit Classroom</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="room_code">Room Code:</label>
                    <input type="text" id="room_code" name="room_code" required maxlength="50" 
                           value="<?= htmlspecialchars($classroom['room_code']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="capacity">Capacity:</label>
                    <input type="number" id="capacity" name="capacity" required min="1" max="500"
                           value="<?= htmlspecialchars((string)$classroom['capacity']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="room_type">Room Type:</label>
                    <select id="room_type" name="room_type" required>
                        <option value="classroom" <?= $classroom['room_type'] === 'classroom' ? 'selected' : '' ?>>Classroom</option>
                        <option value="lab" <?= $classroom['room_type'] === 'lab' ? 'selected' : '' ?>>Laboratory</option>
                    </select>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn">Update Classroom</button>
                    <a href="<?= htmlspecialchars($base) ?>/?page=classrooms" class="btn secondary">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
        
    <?php endif; ?>
</div> 