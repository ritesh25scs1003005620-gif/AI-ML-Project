<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/timetable.php';
require_once __DIR__ . '/../app/batches.php';
require_once __DIR__ . '/../app/faculty.php';
require_once __DIR__ . '/../app/classrooms.php';

$action = $_GET['action'] ?? 'view';
$view_type = $_GET['view_type'] ?? 'all';
$view_id = isset($_GET['view_id']) ? (int)$_GET['view_id'] : 0;
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'generate') {
        $result = generate_timetable();
        if ($result['success']) {
            $message = "Timetable generated successfully! {$result['scheduled_classes']} classes scheduled.";
            if (!empty($result['conflicts'])) {
                $message .= " " . count($result['conflicts']) . " conflicts found.";
            }
        } else {
            $error = $result['message'] ?? 'Failed to generate timetable.';
        }
        $action = 'view';
    } elseif ($action === 'clear') {
        if (clear_timetable()) {
            $message = 'Timetable cleared successfully!';
        } else {
            $error = 'Failed to clear timetable.';
        }
        $action = 'view';
    } elseif ($action === 'export') {
        $csv_content = export_timetable_csv();
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="timetable_' . date('Y-m-d') . '.csv"');
        echo $csv_content;
        exit;
    }
}

$base = BASE_URL;
$days = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$periods = range(1, 8);
?>

<div class="card">
    <h1>Timetable Management</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <div style="margin-bottom: 20px;">
        <form method="POST" style="display: inline-block; margin-right: 10px;">
            <input type="hidden" name="action" value="generate">
            <button type="submit" class="btn" onclick="return confirm('This will clear existing timetable and generate a new one. Continue?')">Generate Timetable</button>
        </form>
        
        <form method="POST" style="display: inline-block; margin-right: 10px;">
            <input type="hidden" name="action" value="clear">
            <button type="submit" class="btn danger" onclick="return confirm('Are you sure you want to clear the timetable?')">Clear Timetable</button>
        </form>
        
        <form method="POST" style="display: inline-block; margin-right: 10px;">
            <input type="hidden" name="action" value="export">
            <button type="submit" class="btn secondary">Export CSV</button>
        </form>
        
        <a href="<?= htmlspecialchars($base) ?>/?page=dashboard" class="btn secondary">Back to Dashboard</a>
    </div>
    
    <!-- View Type Selection -->
    <div class="view-selector" style="margin-bottom: 20px; padding: 15px; background: #f5f5f5; border-radius: 5px;">
        <h3>View Timetable By:</h3>
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="<?= htmlspecialchars($base) ?>/?page=timetable&view_type=all" 
               class="btn <?= $view_type === 'all' ? '' : 'secondary' ?>">All Classes</a>
            
            <select onchange="location.href='<?= htmlspecialchars($base) ?>/?page=timetable&view_type=batch&view_id=' + this.value" 
                    style="margin-right: 10px;">
                <option value="">View by Batch</option>
                <?php
                $batches = get_batches();
                foreach ($batches as $batch):
                ?>
                    <option value="<?= $batch['id'] ?>" <?= $view_type === 'batch' && $view_id == $batch['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($batch['batch_code']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <select onchange="location.href='<?= htmlspecialchars($base) ?>/?page=timetable&view_type=faculty&view_id=' + this.value">
                <option value="">View by Faculty</option>
                <?php
                $faculty_list = get_faculty();
                foreach ($faculty_list as $faculty):
                ?>
                    <option value="<?= $faculty['id'] ?>" <?= $view_type === 'faculty' && $view_id == $faculty['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($faculty['faculty_code']) ?> - <?= htmlspecialchars($faculty['full_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <select onchange="location.href='<?= htmlspecialchars($base) ?>/?page=timetable&view_type=classroom&view_id=' + this.value">
                <option value="">View by Classroom</option>
                <?php
                $classrooms = get_classrooms();
                foreach ($classrooms as $classroom):
                ?>
                    <option value="<?= $classroom['id'] ?>" <?= $view_type === 'classroom' && $view_id == $classroom['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($classroom['room_code']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    
    <?php
    // Get timetable data based on view type
    if ($view_type === 'batch' && $view_id > 0) {
        $timetable_entries = get_timetable_by_batch($view_id);
        $batch = get_batch($view_id);
        $title = $batch ? "Timetable for {$batch['batch_code']}" : "Batch Timetable";
    } elseif ($view_type === 'faculty' && $view_id > 0) {
        $timetable_entries = get_timetable_by_faculty($view_id);
        $faculty = get_faculty_member($view_id);
        $title = $faculty ? "Timetable for {$faculty['full_name']}" : "Faculty Timetable";
    } elseif ($view_type === 'classroom' && $view_id > 0) {
        $timetable_entries = get_timetable_by_classroom($view_id);
        $classroom = get_classroom($view_id);
        $title = $classroom ? "Timetable for {$classroom['room_code']}" : "Classroom Timetable";
    } else {
        $timetable_entries = get_current_timetable();
        $title = "Complete Timetable";
    }
    
    // Organize timetable data into a grid
    $timetable_grid = [];
    foreach ($timetable_entries as $entry) {
        $timetable_grid[$entry['day_of_week']][$entry['period_number']] = $entry;
    }
    ?>
    
    <h2><?= htmlspecialchars($title) ?></h2>
    
    <?php if (empty($timetable_entries)): ?>
        <p>No timetable data found. Please generate a timetable first.</p>
    <?php else: ?>
        <div class="timetable-container" style="overflow-x: auto;">
            <table class="timetable-table" style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <thead>
                    <tr style="background-color: #f8f9fa;">
                        <th style="border: 1px solid #ddd; padding: 10px; text-align: center; min-width: 80px;">Day/Period</th>
                        <?php foreach ($periods as $period): ?>
                            <th style="border: 1px solid #ddd; padding: 10px; text-align: center; min-width: 120px;">
                                Period <?= $period ?>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php for ($day = 1; $day <= 6; $day++): ?>
                        <tr>
                            <td style="border: 1px solid #ddd; padding: 10px; font-weight: bold; background-color: #f8f9fa;">
                                <?= $days[$day] ?>
                            </td>
                            <?php foreach ($periods as $period): ?>
                                <td style="border: 1px solid #ddd; padding: 8px; text-align: center; vertical-align: top;">
                                    <?php if (isset($timetable_grid[$day][$period])): ?>
                                        <?php $entry = $timetable_grid[$day][$period]; ?>
                                        <div class="timetable-entry" style="background: #e3f2fd; padding: 5px; border-radius: 3px; font-size: 12px;">
                                            <?php if ($view_type !== 'batch'): ?>
                                                <div style="font-weight: bold; color: #1976d2;">
                                                    <?= htmlspecialchars($entry['batch_code'] ?? '') ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div style="font-weight: bold;">
                                                <?= htmlspecialchars($entry['subject_code'] ?? $entry['subject_name'] ?? '') ?>
                                            </div>
                                            
                                            <?php if ($view_type !== 'faculty'): ?>
                                                <div style="color: #666;">
                                                    <?= htmlspecialchars($entry['faculty_code'] ?? $entry['faculty_name'] ?? '') ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ($view_type !== 'classroom'): ?>
                                                <div style="color: #666; font-size: 11px;">
                                                    <?= htmlspecialchars($entry['room_code'] ?? '') ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <div style="color: #ccc; font-size: 11px;">Free</div>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
        
        <div style="margin-top: 20px;">
            <h3>Summary</h3>
            <p><strong>Total Classes:</strong> <?= count($timetable_entries) ?></p>
        </div>
    <?php endif; ?>
</div>

<style>
.timetable-table {
    font-size: 14px;
}

.timetable-table th,
.timetable-table td {
    min-height: 60px;
}

.timetable-entry {
    line-height: 1.3;
}

.view-selector select {
    padding: 5px 10px;
    border: 1px solid #ddd;
    border-radius: 3px;
    background: white;
}

@media (max-width: 768px) {
    .timetable-table {
        font-size: 11px;
    }
    
    .timetable-table th,
    .timetable-table td {
        padding: 5px;
        min-width: 80px;
    }
    
    .view-selector {
        text-align: center;
    }
    
    .view-selector div {
        flex-direction: column;
        align-items: center;
    }
    
    .view-selector select {
        margin: 5px 0;
        width: 100%;
        max-width: 250px;
    }
}
</style> 