<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/faculty.php';

$action = $_GET['action'] ?? 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $faculty_code = trim($_POST['faculty_code'] ?? '');
        $full_name = trim($_POST['full_name'] ?? '');
        $max_weekly_load = (int)($_POST['max_weekly_load'] ?? 0);
        
        // Process availability
        $availability = [];
        $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        foreach ($days as $day) {
            $periods = $_POST['availability'][$day] ?? [];
            if (!empty($periods)) {
                $availability[$day] = array_map('intval', $periods);
            }
        }
        
        if ($faculty_code && $full_name && $max_weekly_load > 0) {
            if (create_faculty($faculty_code, $full_name, $max_weekly_load, $availability)) {
                $message = 'Faculty member created successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to create faculty member. Faculty code might already exist.';
            }
        } else {
            $error = 'Please fill all required fields with valid data.';
        }
    } elseif ($action === 'edit' && $id > 0) {
        $faculty_code = trim($_POST['faculty_code'] ?? '');
        $full_name = trim($_POST['full_name'] ?? '');
        $max_weekly_load = (int)($_POST['max_weekly_load'] ?? 0);
        
        // Process availability
        $availability = [];
        $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        foreach ($days as $day) {
            $periods = $_POST['availability'][$day] ?? [];
            if (!empty($periods)) {
                $availability[$day] = array_map('intval', $periods);
            }
        }
        
        if ($faculty_code && $full_name && $max_weekly_load > 0) {
            if (update_faculty($id, $faculty_code, $full_name, $max_weekly_load, $availability)) {
                $message = 'Faculty member updated successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to update faculty member.';
            }
        } else {
            $error = 'Please fill all required fields with valid data.';
        }
    } elseif ($action === 'delete' && $id > 0) {
        if (delete_faculty($id)) {
            $message = 'Faculty member deleted successfully!';
        } else {
            $error = 'Failed to delete faculty member.';
        }
        $action = 'list';
    }
}

$base = BASE_URL;
?>

<div class="card">
    <h1>Manage Faculty</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if ($action === 'list'): ?>
        <div style="margin-bottom: 20px;">
            <a href="<?= htmlspecialchars($base) ?>/?page=faculty&action=create" class="btn">Add New Faculty</a>
            <a href="<?= htmlspecialchars($base) ?>/?page=dashboard" class="btn secondary">Back to Dashboard</a>
        </div>
        
        <?php
        $faculty_list = get_faculty();
        if (empty($faculty_list)):
        ?>
            <p>No faculty members found. <a href="<?= htmlspecialchars($base) ?>/?page=faculty&action=create">Add the first faculty member</a>.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Faculty Code</th>
                        <th>Full Name</th>
                        <th>Max Weekly Load</th>
                        <th>Current Load</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($faculty_list as $faculty): ?>
                        <tr>
                            <td><?= htmlspecialchars($faculty['faculty_code']) ?></td>
                            <td><?= htmlspecialchars($faculty['full_name']) ?></td>
                            <td><?= htmlspecialchars((string)$faculty['max_weekly_load']) ?></td>
                            <td><?= htmlspecialchars((string)get_faculty_workload($faculty['id'])) ?></td>
                            <td>
                                <a href="<?= htmlspecialchars($base) ?>/?page=faculty&action=edit&id=<?= $faculty['id'] ?>" class="btn small">Edit</a>
                                <a href="<?= htmlspecialchars($base) ?>/?page=faculty&action=delete&id=<?= $faculty['id'] ?>" 
                                   class="btn small danger" 
                                   onclick="return confirm('Are you sure you want to delete this faculty member?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
    <?php elseif ($action === 'create'): ?>
        <h2>Add New Faculty Member</h2>
        <form method="POST">
            <div class="form-group">
                <label for="faculty_code">Faculty Code:</label>
                <input type="text" id="faculty_code" name="faculty_code" required maxlength="50" placeholder="e.g., FAC001">
            </div>
            
            <div class="form-group">
                <label for="full_name">Full Name:</label>
                <input type="text" id="full_name" name="full_name" required maxlength="255">
            </div>
            
            <div class="form-group">
                <label for="max_weekly_load">Maximum Weekly Load (hours):</label>
                <input type="number" id="max_weekly_load" name="max_weekly_load" required min="1" max="40" value="12">
            </div>
            
            <div class="form-group">
                <label>Availability (Select periods for each day):</label>
                <div class="availability-grid">
                    <?php
                    $days = ['Mon' => 'Monday', 'Tue' => 'Tuesday', 'Wed' => 'Wednesday', 'Thu' => 'Thursday', 'Fri' => 'Friday', 'Sat' => 'Saturday'];
                    foreach ($days as $day_code => $day_name):
                    ?>
                        <div class="day-availability">
                            <h4><?= $day_name ?></h4>
                            <div class="periods">
                                <?php for ($period = 1; $period <= 8; $period++): ?>
                                    <label class="period-checkbox">
                                        <input type="checkbox" name="availability[<?= $day_code ?>][]" value="<?= $period ?>">
                                        Period <?= $period ?>
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn">Create Faculty</button>
                <a href="<?= htmlspecialchars($base) ?>/?page=faculty" class="btn secondary">Cancel</a>
            </div>
        </form>
        
    <?php elseif ($action === 'edit' && $id > 0): ?>
        <?php
        $faculty = get_faculty_member($id);
        if (!$faculty):
        ?>
            <p>Faculty member not found.</p>
            <a href="<?= htmlspecialchars($base) ?>/?page=faculty" class="btn">Back to Faculty</a>
        <?php else: ?>
            <?php $availability = get_faculty_availability($id); ?>
            <h2>Edit Faculty Member</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="faculty_code">Faculty Code:</label>
                    <input type="text" id="faculty_code" name="faculty_code" required maxlength="50" 
                           value="<?= htmlspecialchars($faculty['faculty_code']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="full_name">Full Name:</label>
                    <input type="text" id="full_name" name="full_name" required maxlength="255"
                           value="<?= htmlspecialchars($faculty['full_name']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="max_weekly_load">Maximum Weekly Load (hours):</label>
                    <input type="number" id="max_weekly_load" name="max_weekly_load" required min="1" max="40"
                           value="<?= htmlspecialchars((string)$faculty['max_weekly_load']) ?>">
                </div>
                
                <div class="form-group">
                    <label>Availability (Select periods for each day):</label>
                    <div class="availability-grid">
                        <?php
                        $days = ['Mon' => 'Monday', 'Tue' => 'Tuesday', 'Wed' => 'Wednesday', 'Thu' => 'Thursday', 'Fri' => 'Friday', 'Sat' => 'Saturday'];
                        foreach ($days as $day_code => $day_name):
                            $day_periods = $availability[$day_code] ?? [];
                        ?>
                            <div class="day-availability">
                                <h4><?= $day_name ?></h4>
                                <div class="periods">
                                    <?php for ($period = 1; $period <= 8; $period++): ?>
                                        <label class="period-checkbox">
                                            <input type="checkbox" name="availability[<?= $day_code ?>][]" value="<?= $period ?>"
                                                   <?= in_array($period, $day_periods) ? 'checked' : '' ?>>
                                            Period <?= $period ?>
                                        </label>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn">Update Faculty</button>
                    <a href="<?= htmlspecialchars($base) ?>/?page=faculty" class="btn secondary">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
        
    <?php endif; ?>
</div>

<style>
.availability-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-top: 10px;
}

.day-availability {
    border: 1px solid #ddd;
    padding: 15px;
    border-radius: 5px;
}

.day-availability h4 {
    margin: 0 0 10px 0;
    color: #333;
}

.periods {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.period-checkbox {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 14px;
}

.period-checkbox input[type="checkbox"] {
    margin: 0;
}
</style> 