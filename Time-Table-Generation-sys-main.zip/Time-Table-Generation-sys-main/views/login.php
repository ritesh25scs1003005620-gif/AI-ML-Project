<?php

declare(strict_types=1);

require_once __DIR__ . '/../app/auth.php';

$base = BASE_URL;
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$email = trim($_POST['email'] ?? '');
	$password = (string)($_POST['password'] ?? '');
	if ($email !== '' && $password !== '') {
		if (login($email, $password)) {
			header('Location: ' . $base . '/?page=dashboard');
			exit;
		}
		$error = 'Invalid credentials';
	} else {
		$error = 'Please enter email and password';
	}
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login - Smart Timetable</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
	<style>
		body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;background:#0f172a;color:#0f172a}
		.center{min-height:100vh;display:flex;align-items:center;justify-content:center}
		.card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:24px;width:360px}
		h1{font-size:22px;margin:0 0 12px}
		input{width:100%;padding:10px;border:1px solid #cbd5e1;border-radius:8px;margin:6px 0}
		button{width:100%;padding:10px;border:none;border-radius:8px;background:#0ea5e9;color:#fff;font-weight:600;margin-top:8px}
		.error{color:#b91c1c;margin:6px 0 0}
	</style>
</head>
<body>
	<div class="center">
		<form class="card" method="post" action="<?= htmlspecialchars($base) ?>/?page=login">
			<h1>Sign in</h1>
			<label>Email</label>
			<input type="email" name="email" placeholder="admin@local" required>
			<label>Password</label>
			<input type="password" name="password" placeholder="admin123" required>
			<?php if ($error): ?>
				<div class="error"><?= htmlspecialchars($error) ?></div>
			<?php endif; ?>
			<button type="submit">Login</button>
		</form>
	</div>
</body>
</html> 