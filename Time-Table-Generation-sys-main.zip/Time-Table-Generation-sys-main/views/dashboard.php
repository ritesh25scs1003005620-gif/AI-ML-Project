<?php

declare(strict_types=1);

$base = BASE_URL;
?>
<div class="card">
	<h1>Dashboard</h1>
	<p>Welcome to Smart Classroom & Timetable Scheduler.</p>
	<div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:10px">
		<a class="btn" href="<?= htmlspecialchars($base) ?>/?page=classrooms">Manage Classrooms</a>
		<a class="btn" href="<?= htmlspecialchars($base) ?>/?page=subjects">Manage Subjects</a>
		<a class="btn" href="<?= htmlspecialchars($base) ?>/?page=faculty">Manage Faculty</a>
		<a class="btn" href="<?= htmlspecialchars($base) ?>/?page=batches">Manage Batches</a>
		<a class="btn secondary" href="<?= htmlspecialchars($base) ?>/?page=mapping">Subject-Faculty Mapping</a>
		<a class="btn secondary" href="<?= htmlspecialchars($base) ?>/?page=timetable">Generate Timetable</a>
	</div>
</div> 