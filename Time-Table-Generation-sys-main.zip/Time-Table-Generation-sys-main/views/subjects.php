<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/subjects.php';

$action = $_GET['action'] ?? 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $subject_code = trim($_POST['subject_code'] ?? '');
        $subject_name = trim($_POST['subject_name'] ?? '');
        $weekly_hours = (int)($_POST['weekly_hours'] ?? 0);
        
        if ($subject_code && $subject_name && $weekly_hours > 0) {
            if (create_subject($subject_code, $subject_name, $weekly_hours)) {
                $message = 'Subject created successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to create subject. Subject code might already exist.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'edit' && $id > 0) {
        $subject_code = trim($_POST['subject_code'] ?? '');
        $subject_name = trim($_POST['subject_name'] ?? '');
        $weekly_hours = (int)($_POST['weekly_hours'] ?? 0);
        
        if ($subject_code && $subject_name && $weekly_hours > 0) {
            if (update_subject($id, $subject_code, $subject_name, $weekly_hours)) {
                $message = 'Subject updated successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to update subject.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'delete' && $id > 0) {
        if (delete_subject($id)) {
            $message = 'Subject deleted successfully!';
        } else {
            $error = 'Failed to delete subject.';
        }
        $action = 'list';
    }
}

$base = BASE_URL;
?>

<div class="card">
    <h1>Manage Subjects</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if ($action === 'list'): ?>
        <div style="margin-bottom: 20px;">
            <a href="<?= htmlspecialchars($base) ?>/?page=subjects&action=create" class="btn">Add New Subject</a>
            <a href="<?= htmlspecialchars($base) ?>/?page=dashboard" class="btn secondary">Back to Dashboard</a>
        </div>
        
        <?php
        $subjects = get_subjects();
        if (empty($subjects)):
        ?>
            <p>No subjects found. <a href="<?= htmlspecialchars($base) ?>/?page=subjects&action=create">Add the first subject</a>.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Subject Code</th>
                        <th>Subject Name</th>
                        <th>Weekly Hours</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($subjects as $subject): ?>
                        <tr>
                            <td><?= htmlspecialchars($subject['subject_code']) ?></td>
                            <td><?= htmlspecialchars($subject['subject_name']) ?></td>
                            <td><?= htmlspecialchars((string)$subject['weekly_hours']) ?></td>
                            <td>
                                <a href="<?= htmlspecialchars($base) ?>/?page=subjects&action=edit&id=<?= $subject['id'] ?>" class="btn small">Edit</a>
                                <a href="<?= htmlspecialchars($base) ?>/?page=subjects&action=delete&id=<?= $subject['id'] ?>" 
                                   class="btn small danger" 
                                   onclick="return confirm('Are you sure you want to delete this subject?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
    <?php elseif ($action === 'create'): ?>
        <h2>Add New Subject</h2>
        <form method="POST">
            <div class="form-group">
                <label for="subject_code">Subject Code:</label>
                <input type="text" id="subject_code" name="subject_code" required maxlength="50">
            </div>
            
            <div class="form-group">
                <label for="subject_name">Subject Name:</label>
                <input type="text" id="subject_name" name="subject_name" required maxlength="255">
            </div>
            
            <div class="form-group">
                <label for="weekly_hours">Weekly Hours:</label>
                <input type="number" id="weekly_hours" name="weekly_hours" required min="1" max="20">
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn">Create Subject</button>
                <a href="<?= htmlspecialchars($base) ?>/?page=subjects" class="btn secondary">Cancel</a>
            </div>
        </form>
        
    <?php elseif ($action === 'edit' && $id > 0): ?>
        <?php
        $subject = get_subject($id);
        if (!$subject):
        ?>
            <p>Subject not found.</p>
            <a href="<?= htmlspecialchars($base) ?>/?page=subjects" class="btn">Back to Subjects</a>
        <?php else: ?>
            <h2>Edit Subject</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="subject_code">Subject Code:</label>
                    <input type="text" id="subject_code" name="subject_code" required maxlength="50" 
                           value="<?= htmlspecialchars($subject['subject_code']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="subject_name">Subject Name:</label>
                    <input type="text" id="subject_name" name="subject_name" required maxlength="255"
                           value="<?= htmlspecialchars($subject['subject_name']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="weekly_hours">Weekly Hours:</label>
                    <input type="number" id="weekly_hours" name="weekly_hours" required min="1" max="20"
                           value="<?= htmlspecialchars((string)$subject['weekly_hours']) ?>">
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn">Update Subject</button>
                    <a href="<?= htmlspecialchars($base) ?>/?page=subjects" class="btn secondary">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
        
    <?php endif; ?>
</div> 