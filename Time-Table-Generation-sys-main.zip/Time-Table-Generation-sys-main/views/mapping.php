<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/mapping.php';
require_once __DIR__ . '/../app/batches.php';
require_once __DIR__ . '/../app/subjects.php';
require_once __DIR__ . '/../app/faculty.php';

$action = $_GET['action'] ?? 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$batch_id = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : 0;
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $batch_id = (int)($_POST['batch_id'] ?? 0);
        $subject_id = (int)($_POST['subject_id'] ?? 0);
        $faculty_id = (int)($_POST['faculty_id'] ?? 0);
        $weekly_hours = (int)($_POST['weekly_hours'] ?? 0);
        
        if ($batch_id > 0 && $subject_id > 0 && $faculty_id > 0 && $weekly_hours > 0) {
            if (create_mapping($batch_id, $subject_id, $faculty_id, $weekly_hours)) {
                $message = 'Subject-Faculty mapping created successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to create mapping. This mapping might already exist.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'edit' && $id > 0) {
        $batch_id = (int)($_POST['batch_id'] ?? 0);
        $subject_id = (int)($_POST['subject_id'] ?? 0);
        $faculty_id = (int)($_POST['faculty_id'] ?? 0);
        $weekly_hours = (int)($_POST['weekly_hours'] ?? 0);
        
        if ($batch_id > 0 && $subject_id > 0 && $faculty_id > 0 && $weekly_hours > 0) {
            if (update_mapping($id, $batch_id, $subject_id, $faculty_id, $weekly_hours)) {
                $message = 'Mapping updated successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to update mapping.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'delete' && $id > 0) {
        if (delete_mapping($id)) {
            $message = 'Mapping deleted successfully!';
        } else {
            $error = 'Failed to delete mapping.';
        }
        $action = 'list';
    }
}

$base = BASE_URL;
?>

<div class="card">
    <h1>Subject-Faculty Mapping</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if ($action === 'list'): ?>
        <div style="margin-bottom: 20px;">
            <a href="<?= htmlspecialchars($base) ?>/?page=mapping&action=create" class="btn">Add New Mapping</a>
            <a href="<?= htmlspecialchars($base) ?>/?page=dashboard" class="btn secondary">Back to Dashboard</a>
        </div>
        
        <?php
        $mappings = get_all_mappings();
        if (empty($mappings)):
        ?>
            <p>No subject-faculty mappings found. <a href="<?= htmlspecialchars($base) ?>/?page=mapping&action=create">Add the first mapping</a>.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Batch</th>
                        <th>Subject</th>
                        <th>Faculty</th>
                        <th>Weekly Hours</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($mappings as $mapping): ?>
                        <tr>
                            <td><?= htmlspecialchars($mapping['batch_code']) ?></td>
                            <td><?= htmlspecialchars($mapping['subject_code']) ?> - <?= htmlspecialchars($mapping['subject_name']) ?></td>
                            <td><?= htmlspecialchars($mapping['faculty_name']) ?> (<?= htmlspecialchars($mapping['faculty_code']) ?>)</td>
                            <td><?= htmlspecialchars((string)$mapping['weekly_hours']) ?></td>
                            <td>
                                <a href="<?= htmlspecialchars($base) ?>/?page=mapping&action=edit&id=<?= $mapping['id'] ?>" class="btn small">Edit</a>
                                <a href="<?= htmlspecialchars($base) ?>/?page=mapping&action=delete&id=<?= $mapping['id'] ?>" 
                                   class="btn small danger" 
                                   onclick="return confirm('Are you sure you want to delete this mapping?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
    <?php elseif ($action === 'create'): ?>
        <h2>Add New Subject-Faculty Mapping</h2>
        <form method="POST">
            <div class="form-group">
                <label for="batch_id">Batch:</label>
                <select id="batch_id" name="batch_id" required>
                    <option value="">Select Batch</option>
                    <?php
                    $batches = get_batches();
                    foreach ($batches as $batch):
                    ?>
                        <option value="<?= $batch['id'] ?>" <?= $batch['id'] == $batch_id ? 'selected' : '' ?>>
                            <?= htmlspecialchars($batch['batch_code']) ?> (Semester <?= $batch['semester'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="subject_id">Subject:</label>
                <select id="subject_id" name="subject_id" required>
                    <option value="">Select Subject</option>
                    <?php
                    $subjects = get_subjects();
                    foreach ($subjects as $subject):
                    ?>
                        <option value="<?= $subject['id'] ?>">
                            <?= htmlspecialchars($subject['subject_code']) ?> - <?= htmlspecialchars($subject['subject_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="faculty_id">Faculty:</label>
                <select id="faculty_id" name="faculty_id" required>
                    <option value="">Select Faculty</option>
                    <?php
                    $faculty_list = get_faculty();
                    foreach ($faculty_list as $faculty):
                        $current_load = get_faculty_workload($faculty['id']);
                    ?>
                        <option value="<?= $faculty['id'] ?>">
                            <?= htmlspecialchars($faculty['faculty_code']) ?> - <?= htmlspecialchars($faculty['full_name']) ?>
                            (Load: <?= $current_load ?>/<?= $faculty['max_weekly_load'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="weekly_hours">Weekly Hours:</label>
                <input type="number" id="weekly_hours" name="weekly_hours" required min="1" max="10" placeholder="Hours per week">
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn">Create Mapping</button>
                <a href="<?= htmlspecialchars($base) ?>/?page=mapping" class="btn secondary">Cancel</a>
            </div>
        </form>
        
    <?php elseif ($action === 'edit' && $id > 0): ?>
        <?php
        $mapping = get_mapping($id);
        if (!$mapping):
        ?>
            <p>Mapping not found.</p>
            <a href="<?= htmlspecialchars($base) ?>/?page=mapping" class="btn">Back to Mappings</a>
        <?php else: ?>
            <h2>Edit Subject-Faculty Mapping</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="batch_id">Batch:</label>
                    <select id="batch_id" name="batch_id" required>
                        <option value="">Select Batch</option>
                        <?php
                        $batches = get_batches();
                        foreach ($batches as $batch):
                        ?>
                            <option value="<?= $batch['id'] ?>" <?= $batch['id'] == $mapping['batch_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($batch['batch_code']) ?> (Semester <?= $batch['semester'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="subject_id">Subject:</label>
                    <select id="subject_id" name="subject_id" required>
                        <option value="">Select Subject</option>
                        <?php
                        $subjects = get_subjects();
                        foreach ($subjects as $subject):
                        ?>
                            <option value="<?= $subject['id'] ?>" <?= $subject['id'] == $mapping['subject_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($subject['subject_code']) ?> - <?= htmlspecialchars($subject['subject_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="faculty_id">Faculty:</label>
                    <select id="faculty_id" name="faculty_id" required>
                        <option value="">Select Faculty</option>
                        <?php
                        $faculty_list = get_faculty();
                        foreach ($faculty_list as $faculty):
                            $current_load = get_faculty_workload($faculty['id']);
                        ?>
                            <option value="<?= $faculty['id'] ?>" <?= $faculty['id'] == $mapping['faculty_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($faculty['faculty_code']) ?> - <?= htmlspecialchars($faculty['full_name']) ?>
                                (Load: <?= $current_load ?>/<?= $faculty['max_weekly_load'] ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="weekly_hours">Weekly Hours:</label>
                    <input type="number" id="weekly_hours" name="weekly_hours" required min="1" max="10"
                           value="<?= htmlspecialchars((string)$mapping['weekly_hours']) ?>">
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn">Update Mapping</button>
                    <a href="<?= htmlspecialchars($base) ?>/?page=mapping" class="btn secondary">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
        
    <?php endif; ?>
</div>