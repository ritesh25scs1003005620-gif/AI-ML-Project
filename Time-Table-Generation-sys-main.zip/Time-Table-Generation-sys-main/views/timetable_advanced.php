<?php require_once "../app/timetable_advanced.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Timetable Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .timetable-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .option-card {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .option-card:hover {
            border-color: #007bff;
            box-shadow: 0 4px 12px rgba(0,123,255,0.15);
        }
        .option-card.selected {
            border-color: #28a745;
            background-color: #f8fff9;
        }
        .score-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
            border-radius: 20px;
            padding: 5px 12px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        .timetable-grid {
            overflow-x: auto;
        }
        .period-cell {
            min-width: 120px;
            height: 60px;
            border: 1px solid #dee2e6;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-size: 0.8rem;
            position: relative;
        }
        .subject-code {
            font-weight: bold;
            color: #495057;
        }
        .faculty-code {
            color: #6c757d;
            font-size: 0.7rem;
        }
        .room-code {
            color: #007bff;
            font-size: 0.7rem;
        }
        .analytics-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }
        .progress-ring {
            width: 60px;
            height: 60px;
        }
        .progress-ring-circle {
            fill: none;
            stroke: #e9ecef;
            stroke-width: 4;
        }
        .progress-ring-progress {
            fill: none;
            stroke: #28a745;
            stroke-width: 4;
            stroke-linecap: round;
            transform: rotate(-90deg);
            transform-origin: 50% 50%;
        }
        .conflict-badge {
            background: #dc3545;
            color: white;
            border-radius: 15px;
            padding: 2px 8px;
            font-size: 0.7rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container-fluid py-4">
        <!-- Header -->
        <div class="timetable-card text-center">
            <h1><i class="fas fa-calendar-alt me-3"></i>Smart Timetable Generator</h1>
            <p class="mb-0">AI-Powered Optimization for Academic Scheduling</p>
        </div>

        <!-- Generation Controls -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-cogs me-2"></i>Generation Settings</h5>
                        <form id="generateForm">
                            <div class="row">
                                <div class="col-md-4">
                                    <label class="form-label">Number of Options</label>
                                    <select class="form-select" name="num_options">
                                        <option value="3" selected>3 Options</option>
                                        <option value="5">5 Options</option>
                                        <option value="7">7 Options</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Max Classes per Day</label>
                                    <input type="number" class="form-control" name="max_classes_per_day" value="6" min="4" max="8">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Priority</label>
                                    <select class="form-select" name="priority">
                                        <option value="balanced">Balanced Distribution</option>
                                        <option value="conflicts">Minimize Conflicts</option>
                                        <option value="faculty">Faculty Preference</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-magic me-2"></i>Generate Optimized Timetables
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-lg ms-2" onclick="showAnalytics()">
                                    <i class="fas fa-chart-bar me-2"></i>View Analytics
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body text-center">
                        <h5 class="card-title">Quick Stats</h5>
                        <div class="row">
                            <div class="col-6">
                                <h3 class="text-primary" id="totalBatches"><?= count(db_fetch_all(db_query("SELECT * FROM batches"))) ?></h3>
                                <small class="text-muted">Batches</small>
                            </div>
                            <div class="col-6">
                                <h3 class="text-success" id="totalFaculty"><?= count(db_fetch_all(db_query("SELECT * FROM faculty"))) ?></h3>
                                <small class="text-muted">Faculty</small>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-6">
                                <h3 class="text-info" id="totalClassrooms"><?= count(db_fetch_all(db_query("SELECT * FROM classrooms"))) ?></h3>
                                <small class="text-muted">Classrooms</small>
                            </div>
                            <div class="col-6">
                                <h3 class="text-warning" id="totalSubjects"><?= count(db_fetch_all(db_query("SELECT * FROM subjects"))) ?></h3>
                                <small class="text-muted">Subjects</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Results Section -->
        <div id="resultsSection" style="display: none;">
            <!-- Options Selection -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-list-alt me-2"></i>Generated Options</h5>
                    <p class="text-muted">Select the best timetable option based on your preferences:</p>
                    <div id="optionsContainer" class="row">
                        <!-- Options will be populated here -->
                    </div>
                </div>
            </div>

            <!-- Selected Timetable Display -->
            <div id="selectedTimetable" class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="card-title mb-0"><i class="fas fa-table me-2"></i>Selected Timetable</h5>
                        <div>
                            <button class="btn btn-success" onclick="approveTimetable()">
                                <i class="fas fa-check me-2"></i>Approve & Save
                            </button>
                            <button class="btn btn-outline-primary" onclick="exportTimetable()">
                                <i class="fas fa-download me-2"></i>Export CSV
                            </button>
                        </div>
                    </div>
                    <div id="timetableDisplay">
                        <!-- Timetable will be displayed here -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Analytics Modal -->
        <div class="modal fade" id="analyticsModal" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><i class="fas fa-chart-bar me-2"></i>Timetable Analytics</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body" id="analyticsContent">
                        <!-- Analytics content will be loaded here -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let generatedOptions = [];
        let selectedOption = null;

        document.getElementById('generateForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            const numOptions = parseInt(formData.get('num_options'));
            
            // Show loading
            const submitBtn = e.target.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Generating...';
            submitBtn.disabled = true;
            
            try {
                const response = await fetch('api/generate_timetables.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    generatedOptions = result.options;
                    displayOptions(result.options);
                    document.getElementById('resultsSection').style.display = 'block';
                } else {
                    alert('Failed to generate timetables: ' + (result.message || 'Unknown error'));
                }
            } catch (error) {
                alert('Error generating timetables: ' + error.message);
            } finally {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        });

        function displayOptions(options) {
            const container = document.getElementById('optionsContainer');
            container.innerHTML = '';
            
            options.forEach((option, index) => {
                const optionCard = document.createElement('div');
                optionCard.className = 'col-md-4 mb-3';
                optionCard.innerHTML = `
                    <div class="option-card card h-100 position-relative" onclick="selectOption(${index})">
                        <div class="score-badge">${option.score.toFixed(1)}</div>
                        <div class="card-body">
                            <h6 class="card-title">${option.strategy}</h6>
                            <div class="mb-2">
                                <small class="text-success">
                                    <i class="fas fa-check-circle me-1"></i>
                                    ${option.scheduled_classes} classes scheduled
                                </small>
                            </div>
                            ${option.conflicts.length > 0 ? `
                                <div class="mb-2">
                                    <small class="text-warning">
                                        <i class="fas fa-exclamation-triangle me-1"></i>
                                        ${option.conflicts.length} conflicts
                                    </small>
                                </div>
                            ` : ''}
                            <div class="mb-2">
                                <small class="text-info">
                                    Coverage: ${option.coverage.percentage.toFixed(1)}%
                                </small>
                            </div>
                            ${option.suggestions.length > 0 ? `
                                <div class="mt-2">
                                    <small class="text-muted">
                                        <i class="fas fa-lightbulb me-1"></i>
                                        ${option.suggestions.length} suggestions
                                    </small>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
                container.appendChild(optionCard);
            });
            
            // Auto-select the best option
            if (options.length > 0) {
                selectOption(0);
            }
        }

        function selectOption(index) {
            // Remove previous selection
            document.querySelectorAll('.option-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Select new option
            const selectedCard = document.querySelectorAll('.option-card')[index];
            selectedCard.classList.add('selected');
            
            selectedOption = generatedOptions[index];
            displayTimetable(selectedOption);
        }

        function displayTimetable(option) {
            const container = document.getElementById('timetableDisplay');
            
            // Create timetable HTML
            let html = '<div class="timetable-grid"><table class="table table-bordered">';
            html += '<thead class="table-dark"><tr><th>Batch</th>';
            
            const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
            days.forEach(day => {
                html += `<th colspan="8" class="text-center">${day}</th>`;
            });
            html += '</tr><tr><th></th>';
            
            for (let day = 0; day < 5; day++) {
                for (let period = 1; period <= 8; period++) {
                    html += `<th class="text-center" style="min-width: 100px;">P${period}</th>`;
                }
            }
            html += '</tr></thead><tbody>';
            
            // Get batches for display
            const batches = <?= json_encode(db_fetch_all(db_query("SELECT * FROM batches ORDER BY batch_code"))) ?>;
            
            batches.forEach(batch => {
                html += `<tr><td class="fw-bold">${batch.batch_code}</td>`;
                
                for (let day = 1; day <= 5; day++) {
                    for (let period = 1; period <= 8; period++) {
                        const classData = findClassInSchedule(option.schedule, batch.id, day, period);
                        
                        if (classData) {
                            html += `<td class="period-cell bg-light">
                                <div class="subject-code">${classData.subject_code}</div>
                                <div class="faculty-code">${classData.faculty_code}</div>
                                <div class="room-code">${classData.room_code}</div>
                            </td>`;
                        } else {
                            html += '<td class="period-cell"></td>';
                        }
                    }
                }
                html += '</tr>';
            });
            
            html += '</tbody></table></div>';
            
            // Add conflicts and suggestions
            if (option.conflicts.length > 0) {
                html += '<div class="mt-3"><h6 class="text-warning">Conflicts:</h6><ul class="list-unstyled">';
                option.conflicts.forEach(conflict => {
                    html += `<li><span class="conflict-badge">!</span> ${conflict.batch_code} - ${conflict.subject_code} (${conflict.faculty_code}): ${conflict.message}</li>`;
                });
                html += '</ul></div>';
            }
            
            if (option.suggestions.length > 0) {
                html += '<div class="mt-3"><h6 class="text-info">Suggestions:</h6><ul>';
                option.suggestions.forEach(suggestion => {
                    html += `<li>${suggestion}</li>`;
                });
                html += '</ul></div>';
            }
            
            container.innerHTML = html;
        }

        function findClassInSchedule(schedule, batchId, day, period) {
            // This would need to be implemented based on the actual schedule format
            // For now, return null as placeholder
            return null;
        }

        async function showAnalytics() {
            try {
                const response = await fetch('api/timetable_analytics.php');
                const analytics = await response.json();
                
                let html = '<div class="row">';
                
                // Faculty utilization
                html += '<div class="col-md-6"><div class="analytics-card">';
                html += '<h6><i class="fas fa-user-tie me-2"></i>Faculty Utilization</h6>';
                analytics.faculty_utilization.forEach(faculty => {
                    html += `<div class="d-flex justify-content-between align-items-center mb-2">
                        <span>${faculty.faculty_code}</span>
                        <div class="progress" style="width: 60%;">
                            <div class="progress-bar" style="width: ${faculty.utilization_percent}%">${faculty.utilization_percent}%</div>
                        </div>
                    </div>`;
                });
                html += '</div></div>';
                
                // Classes per day
                html += '<div class="col-md-6"><div class="analytics-card">';
                html += '<h6><i class="fas fa-calendar-day me-2"></i>Classes per Day</h6>';
                const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                Object.entries(analytics.classes_per_day).forEach(([day, count]) => {
                    const dayName = dayNames[day - 1] || `Day ${day}`;
                    html += `<div class="d-flex justify-content-between align-items-center mb-2">
                        <span>${dayName}</span>
                        <span class="badge bg-primary">${count} classes</span>
                    </div>`;
                });
                html += '</div></div>';
                
                html += '</div>';
                
                document.getElementById('analyticsContent').innerHTML = html;
                new bootstrap.Modal(document.getElementById('analyticsModal')).show();
            } catch (error) {
                alert('Error loading analytics: ' + error.message);
            }
        }

        async function approveTimetable() {
            if (!selectedOption) {
                alert('Please select a timetable option first');
                return;
            }
            
            if (confirm('Are you sure you want to approve and save this timetable?')) {
                try {
                    const response = await fetch('api/approve_timetable.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            option_id: selectedOption.option_id,
                            schedule: selectedOption.schedule
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        alert('Timetable approved and saved successfully!');
                    } else {
                        alert('Error approving timetable: ' + result.message);
                    }
                } catch (error) {
                    alert('Error approving timetable: ' + error.message);
                }
            }
        }

        function exportTimetable() {
            if (!selectedOption) {
                alert('Please select a timetable option first');
                return;
            }
            
            window.open('api/export_timetable.php?format=csv', '_blank');
        }
    </script>
</body>
</html> 