<?php
declare(strict_types=1);

require_once __DIR__ . '/../app/batches.php';

$action = $_GET['action'] ?? 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$message = '';
$error = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'create') {
        $batch_code = trim($_POST['batch_code'] ?? '');
        $semester = (int)($_POST['semester'] ?? 0);
        $size = (int)($_POST['size'] ?? 0);
        
        if ($batch_code && $semester > 0 && $size > 0) {
            if (create_batch($batch_code, $semester, $size)) {
                $message = 'Batch created successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to create batch. Batch code might already exist.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'edit' && $id > 0) {
        $batch_code = trim($_POST['batch_code'] ?? '');
        $semester = (int)($_POST['semester'] ?? 0);
        $size = (int)($_POST['size'] ?? 0);
        
        if ($batch_code && $semester > 0 && $size > 0) {
            if (update_batch($id, $batch_code, $semester, $size)) {
                $message = 'Batch updated successfully!';
                $action = 'list';
            } else {
                $error = 'Failed to update batch.';
            }
        } else {
            $error = 'Please fill all fields with valid data.';
        }
    } elseif ($action === 'delete' && $id > 0) {
        if (delete_batch($id)) {
            $message = 'Batch deleted successfully!';
        } else {
            $error = 'Failed to delete batch.';
        }
        $action = 'list';
    }
}

$base = BASE_URL;
?>

<div class="card">
    <h1>Manage Student Batches</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if ($action === 'list'): ?>
        <div style="margin-bottom: 20px;">
            <a href="<?= htmlspecialchars($base) ?>/?page=batches&action=create" class="btn">Add New Batch</a>
            <a href="<?= htmlspecialchars($base) ?>/?page=dashboard" class="btn secondary">Back to Dashboard</a>
        </div>
        
        <?php
        $batches = get_batches();
        if (empty($batches)):
        ?>
            <p>No batches found. <a href="<?= htmlspecialchars($base) ?>/?page=batches&action=create">Add the first batch</a>.</p>
        <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Batch Code</th>
                        <th>Semester</th>
                        <th>Size</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($batches as $batch): ?>
                        <tr>
                            <td><?= htmlspecialchars($batch['batch_code']) ?></td>
                            <td><?= htmlspecialchars((string)$batch['semester']) ?></td>
                            <td><?= htmlspecialchars((string)$batch['size']) ?></td>
                            <td>
                                <a href="<?= htmlspecialchars($base) ?>/?page=batches&action=edit&id=<?= $batch['id'] ?>" class="btn small">Edit</a>
                                <a href="<?= htmlspecialchars($base) ?>/?page=batches&action=view&id=<?= $batch['id'] ?>" class="btn small secondary">View Subjects</a>
                                <a href="<?= htmlspecialchars($base) ?>/?page=batches&action=delete&id=<?= $batch['id'] ?>" 
                                   class="btn small danger" 
                                   onclick="return confirm('Are you sure you want to delete this batch?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
        
    <?php elseif ($action === 'create'): ?>
        <h2>Add New Batch</h2>
        <form method="POST">
            <div class="form-group">
                <label for="batch_code">Batch Code:</label>
                <input type="text" id="batch_code" name="batch_code" required maxlength="50" placeholder="e.g., CS-2023, ME-A1">
            </div>
            
            <div class="form-group">
                <label for="semester">Semester:</label>
                <input type="number" id="semester" name="semester" required min="1" max="12" placeholder="1-12">
            </div>
            
            <div class="form-group">
                <label for="size">Batch Size:</label>
                <input type="number" id="size" name="size" required min="1" max="200" placeholder="Number of students">
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn">Create Batch</button>
                <a href="<?= htmlspecialchars($base) ?>/?page=batches" class="btn secondary">Cancel</a>
            </div>
        </form>
        
    <?php elseif ($action === 'edit' && $id > 0): ?>
        <?php
        $batch = get_batch($id);
        if (!$batch):
        ?>
            <p>Batch not found.</p>
            <a href="<?= htmlspecialchars($base) ?>/?page=batches" class="btn">Back to Batches</a>
        <?php else: ?>
            <h2>Edit Batch</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="batch_code">Batch Code:</label>
                    <input type="text" id="batch_code" name="batch_code" required maxlength="50" 
                           value="<?= htmlspecialchars($batch['batch_code']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="semester">Semester:</label>
                    <input type="number" id="semester" name="semester" required min="1" max="12"
                           value="<?= htmlspecialchars((string)$batch['semester']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="size">Batch Size:</label>
                    <input type="number" id="size" name="size" required min="1" max="200"
                           value="<?= htmlspecialchars((string)$batch['size']) ?>">
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn">Update Batch</button>
                    <a href="<?= htmlspecialchars($base) ?>/?page=batches" class="btn secondary">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
        
    <?php elseif ($action === 'view' && $id > 0): ?>
        <?php
        $batch = get_batch($id);
        if (!$batch):
        ?>
            <p>Batch not found.</p>
            <a href="<?= htmlspecialchars($base) ?>/?page=batches" class="btn">Back to Batches</a>
        <?php else: ?>
            <h2>Subjects for <?= htmlspecialchars($batch['batch_code']) ?></h2>
            <div style="margin-bottom: 20px;">
                <a href="<?= htmlspecialchars($base) ?>/?page=mapping&action=create&batch_id=<?= $batch['id'] ?>" class="btn">Add Subject-Faculty Mapping</a>
                <a href="<?= htmlspecialchars($base) ?>/?page=batches" class="btn secondary">Back to Batches</a>
            </div>
            
            <?php
            $subjects = get_batch_subjects($id);
            if (empty($subjects)):
            ?>
                <p>No subjects assigned to this batch. <a href="<?= htmlspecialchars($base) ?>/?page=mapping&action=create&batch_id=<?= $batch['id'] ?>">Add the first subject-faculty mapping</a>.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th>Faculty</th>
                            <th>Weekly Hours</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subjects as $subject): ?>
                            <tr>
                                <td><?= htmlspecialchars($subject['subject_code']) ?></td>
                                <td><?= htmlspecialchars($subject['subject_name']) ?></td>
                                <td><?= htmlspecialchars($subject['faculty_name']) ?> (<?= htmlspecialchars($subject['faculty_code']) ?>)</td>
                                <td><?= htmlspecialchars((string)$subject['weekly_hours']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
        
    <?php endif; ?>
</div> 