<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once "../app/timetable_advanced.php";

try {
    $analytics = get_timetable_analytics();
    echo json_encode($analytics);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error loading analytics: ' . $e->getMessage()
    ]);
} 