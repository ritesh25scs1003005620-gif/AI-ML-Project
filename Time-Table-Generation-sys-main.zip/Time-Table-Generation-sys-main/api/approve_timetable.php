<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once "../app/timetable.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['option_id'])) {
        throw new Exception('Invalid input data');
    }
    
    // The timetable is already saved in the database during generation
    // This endpoint can be used for additional approval workflow steps
    
    // For now, just return success
    echo json_encode([
        'success' => true,
        'message' => 'Timetable approved successfully',
        'approved_at' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error approving timetable: ' . $e->getMessage()
    ]);
} 