<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once "../app/timetable_advanced.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $numOptions = isset($_POST['num_options']) ? (int)$_POST['num_options'] : 3;
    $numOptions = max(1, min(10, $numOptions)); // Limit between 1-10
    
    $result = generate_optimized_timetables($numOptions);
    
    echo json_encode($result);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error generating timetables: ' . $e->getMessage()
    ]);
} 