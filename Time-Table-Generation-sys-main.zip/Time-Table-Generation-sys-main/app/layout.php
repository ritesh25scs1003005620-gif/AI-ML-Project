<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

function render_layout(string $contentHtml, string $title = 'Smart Timetable'): string {
	$user = current_user();
	$base = BASE_URL;
	$nav = '';
	if ($user) {
		$nav = '<nav style="display:flex;gap:12px;padding:10px;background:#0f172a;color:white">'
			. '<strong style="margin-right:auto">Smart Timetable</strong>'
			. '<a style="color:#fff" href="' . $base . '/?page=dashboard">Dashboard</a>'
			. '<a style="color:#fff" href="' . $base . '/?page=classrooms">Classrooms</a>'
			. '<a style="color:#fff" href="' . $base . '/?page=subjects">Subjects</a>'
			. '<a style="color:#fff" href="' . $base . '/?page=faculty">Faculty</a>'
			. '<a style="color:#fff" href="' . $base . '/?page=batches">Batches</a>'
			. '<a style="color:#fff" href="' . $base . '/?page=mapping">Mapping</a>'
			. '<a style="color:#fff" href="' . $base . '/?page=timetable">Timetable</a>'
			. '<span style="margin-left:auto"></span>'
			. '<span>' . htmlspecialchars($user['full_name']) . ' (' . htmlspecialchars($user['role']) . ')</span>'
			. '<a style="color:#fff" href="' . $base . '/?page=logout">Logout</a>'
			. '</nav>';
	}
	return '<!doctype html>'
		. '<html lang="en"><head>'
		. '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
		. '<title>' . htmlspecialchars($title) . '</title>'
		. '<link rel="preconnect" href="https://fonts.googleapis.com">'
		. '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
		. '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">'
		. '<style>
			body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;margin:0;background:#f8fafc;color:#0f172a;line-height:1.6} 
			a{text-decoration:none} 
			.container{max-width:1200px;margin:20px auto;padding:0 16px} 
			.card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:24px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,0.1)} 
			h1{font-size:28px;margin:0 0 16px;font-weight:600} 
			h2{font-size:22px;margin:20px 0 12px;font-weight:600} 
			h3{font-size:18px;margin:16px 0 8px;font-weight:600} 
			h4{font-size:16px;margin:12px 0 6px;font-weight:600}
			.table{width:100%;border-collapse:collapse;margin-top:16px} 
			.table th,.table td{border:1px solid #e5e7eb;padding:12px;text-align:left;vertical-align:top} 
			.table th{background:#f8fafc;font-weight:600} 
			.table tr:nth-child(even){background:#f9fafb}
			.btn{display:inline-block;padding:10px 16px;border-radius:6px;background:#0ea5e9;color:#fff;font-weight:500;border:none;cursor:pointer;transition:all 0.2s} 
			.btn:hover{background:#0284c7;transform:translateY(-1px)} 
			.btn.secondary{background:#64748b} 
			.btn.secondary:hover{background:#475569} 
			.btn.danger{background:#dc2626} 
			.btn.danger:hover{background:#b91c1c} 
			.btn.small{padding:6px 12px;font-size:14px}
			.form-group{margin-bottom:16px} 
			.form-group label{display:block;margin-bottom:6px;font-weight:500;color:#374151} 
			.form-group input,.form-group select,.form-group textarea{width:100%;padding:10px;border:1px solid #d1d5db;border-radius:6px;font-size:14px;box-sizing:border-box} 
			.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:#0ea5e9;box-shadow:0 0 0 3px rgba(14,165,233,0.1)} 
			.form-actions{display:flex;gap:12px;margin-top:24px;flex-wrap:wrap} 
			.alert{padding:12px 16px;border-radius:6px;margin-bottom:16px} 
			.alert.alert-success{background:#dcfce7;color:#166534;border:1px solid #bbf7d0} 
			.alert.alert-error{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
			nav{flex-wrap:wrap}
			nav a{padding:8px 12px;border-radius:4px;transition:background 0.2s}
			nav a:hover{background:rgba(255,255,255,0.1)}
			@media (max-width: 768px) {
				.container{padding:0 12px}
				.card{padding:16px}
				.form-actions{flex-direction:column}
				.btn{text-align:center}
				nav{flex-direction:column;gap:8px}
				nav span{order:-1}
				.table{font-size:14px}
				.table th,.table td{padding:8px}
			}
		</style>'
		. '</head><body>' . $nav . '<div class="container">' . $contentHtml . '</div></body></html>';
} 