<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";

function get_batches(): array {
    $stmt = db_query("SELECT * FROM batches ORDER BY batch_code");
    return db_fetch_all($stmt);
}

function get_batch(int $id): ?array {
    $stmt = db_query("SELECT * FROM batches WHERE id = ?", "i", [$id]);
    return db_fetch_one($stmt);
}

function create_batch(string $batch_code, int $semester, int $size): bool {
    try {
        db_query("INSERT INTO batches (batch_code, semester, size) VALUES (?, ?, ?)", 
                "sii", [$batch_code, $semester, $size]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function update_batch(int $id, string $batch_code, int $semester, int $size): bool {
    try {
        $stmt = db_query("UPDATE batches SET batch_code = ?, semester = ?, size = ? WHERE id = ?", 
                         "siii", [$batch_code, $semester, $size, $id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function delete_batch(int $id): bool {
    try {
        $stmt = db_query("DELETE FROM batches WHERE id = ?", "i", [$id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function get_batch_subjects(int $batch_id): array {
    $stmt = db_query("SELECT bsf.*, s.subject_name, s.subject_code, f.full_name as faculty_name, f.faculty_code 
                     FROM batch_subject_faculty bsf
                     JOIN subjects s ON bsf.subject_id = s.id
                     JOIN faculty f ON bsf.faculty_id = f.id
                     WHERE bsf.batch_id = ?
                     ORDER BY s.subject_code", "i", [$batch_id]);
    return db_fetch_all($stmt);
} 