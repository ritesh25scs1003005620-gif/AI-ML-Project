<?php

declare(strict_types=1);

require_once __DIR__ . '/layout.php';
require_once __DIR__ . '/auth.php';

function handle_route(string $route): string {
	switch ($route) {
		case 'dashboard':
			ob_start();
			require __DIR__ . '/../views/dashboard.php';
			return (string)ob_get_clean();
		case 'login':
			ob_start();
			require __DIR__ . '/../views/login.php';
			return (string)ob_get_clean();
		case 'subjects':
			ob_start();
			require __DIR__ . '/../views/subjects.php';
			return (string)ob_get_clean();
		case 'classrooms':
			ob_start();
			require __DIR__ . '/../views/classrooms.php';
			return (string)ob_get_clean();
		case 'faculty':
			ob_start();
			require __DIR__ . '/../views/faculty.php';
			return (string)ob_get_clean();
		case 'batches':
			ob_start();
			require __DIR__ . '/../views/batches.php';
			return (string)ob_get_clean();
		case 'mapping':
			ob_start();
			require __DIR__ . '/../views/mapping.php';
			return (string)ob_get_clean();
		case 'timetable':
			ob_start();
			require __DIR__ . '/../views/timetable.php';
			return (string)ob_get_clean();
		case 'logout':
			logout();
			header('Location: ' . BASE_URL . '/?page=login');
			exit;
		default:
			return '<div class="card"><h1>Not Found</h1><p>Unknown page.</p></div>';
	}
}

function render_stub(string $name): string {
	$namePretty = ucfirst($name);
	return '<div class="card"><h1>' . htmlspecialchars($namePretty) . '</h1><p>Coming soon...</p></div>';
} 