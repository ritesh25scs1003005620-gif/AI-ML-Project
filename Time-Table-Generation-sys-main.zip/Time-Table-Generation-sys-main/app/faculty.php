<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";

function get_faculty(): array {
    $stmt = db_query("SELECT * FROM faculty ORDER BY faculty_code");
    return db_fetch_all($stmt);
}

function get_faculty_member(int $id): ?array {
    $stmt = db_query("SELECT * FROM faculty WHERE id = ?", "i", [$id]);
    return db_fetch_one($stmt);
}

function create_faculty(string $faculty_code, string $full_name, int $max_weekly_load, array $availability): bool {
    try {
        $availability_json = json_encode($availability);
        db_query("INSERT INTO faculty (faculty_code, full_name, max_weekly_load, availability_json) VALUES (?, ?, ?, ?)", 
                "ssis", [$faculty_code, $full_name, $max_weekly_load, $availability_json]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function update_faculty(int $id, string $faculty_code, string $full_name, int $max_weekly_load, array $availability): bool {
    try {
        $availability_json = json_encode($availability);
        $stmt = db_query("UPDATE faculty SET faculty_code = ?, full_name = ?, max_weekly_load = ?, availability_json = ? WHERE id = ?", 
                         "ssisi", [$faculty_code, $full_name, $max_weekly_load, $availability_json, $id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function delete_faculty(int $id): bool {
    try {
        $stmt = db_query("DELETE FROM faculty WHERE id = ?", "i", [$id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function get_faculty_availability(int $faculty_id): array {
    $faculty = get_faculty_member($faculty_id);
    if (!$faculty) return [];
    
    $availability = json_decode($faculty['availability_json'], true);
    return $availability ?: [];
}

function is_faculty_available(int $faculty_id, int $day, int $period): bool {
    $availability = get_faculty_availability($faculty_id);
    $day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    $day_name = $day_names[$day - 1] ?? '';
    
    return isset($availability[$day_name]) && in_array($period, $availability[$day_name]);
}

function get_faculty_workload(int $faculty_id): int {
    $stmt = db_query("SELECT SUM(bsf.weekly_hours) as total_hours 
                     FROM batch_subject_faculty bsf 
                     WHERE bsf.faculty_id = ?", "i", [$faculty_id]);
    $result = db_fetch_one($stmt);
    return (int)($result['total_hours'] ?? 0);
} 