<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/faculty.php";
require_once __DIR__ . "/mapping.php";
require_once __DIR__ . "/timetable.php";

/**
 * Advanced Timetable Generation System
 * Implements optimization algorithms for hackathon requirements
 */

class TimetableOptimizer {
    private array $classrooms;
    private array $batches;
    private array $subjects;
    private array $faculty;
    private array $mappings;
    private array $constraints;
    
    // Scheduling parameters
    private int $maxPeriodsPerDay = 8;
    private int $workingDays = 6; // Monday to Saturday (excluding Sunday)
    private int $requiredClassesPerDay = 6; // Each batch needs 6 classes per day
    private array $fixedSlots = [];
    private array $facultyLeaves = [];
    
    public function __construct() {
        $this->loadData();
        $this->constraints = [
            'max_classes_per_day' => 6,
            'min_gap_between_classes' => 0,
            'prefer_morning_slots' => true,
            'avoid_last_period' => true,
            'distribute_evenly' => true
        ];
    }
    
    private function loadData(): void {
        // Load classrooms
        $stmt = db_query("SELECT * FROM classrooms ORDER BY capacity DESC");
        $this->classrooms = db_fetch_all($stmt);
        
        // Load batches
        $stmt = db_query("SELECT * FROM batches ORDER BY batch_code");
        $this->batches = db_fetch_all($stmt);
        
        // Load subjects
        $stmt = db_query("SELECT * FROM subjects ORDER BY subject_code");
        $this->subjects = db_fetch_all($stmt);
        
        // Load faculty
        $stmt = db_query("SELECT * FROM faculty ORDER BY faculty_code");
        $this->faculty = db_fetch_all($stmt);
        
        // Load mappings
        $this->mappings = get_all_mappings();
    }
    
    /**
     * Generate multiple optimized timetable options
     */
    public function generateOptimizedTimetables(int $numOptions = 3): array {
        $results = [];
        
        for ($i = 0; $i < $numOptions; $i++) {
            // Use different optimization strategies for each option
            $strategy = $this->getOptimizationStrategy($i);
            $result = $this->generateSingleTimetable($strategy);
            
            if ($result['success']) {
                $result['option_id'] = $i + 1;
                $result['strategy'] = $strategy['name'];
                $result['score'] = $this->calculateTimetableScore($result['schedule']);
                $results[] = $result;
            }
        }
        
        // Sort by score (higher is better)
        usort($results, fn($a, $b) => $b['score'] <=> $a['score']);
        
        return [
            'success' => !empty($results),
            'options' => $results,
            'best_option' => $results[0] ?? null
        ];
    }
    
    private function getOptimizationStrategy(int $index): array {
        $strategies = [
            0 => [
                'name' => 'Balanced Distribution',
                'priority' => 'distribute_evenly',
                'weights' => ['balance' => 0.4, 'conflicts' => 0.3, 'preferences' => 0.3]
            ],
            1 => [
                'name' => 'Minimize Conflicts',
                'priority' => 'avoid_conflicts',
                'weights' => ['balance' => 0.2, 'conflicts' => 0.5, 'preferences' => 0.3]
            ],
            2 => [
                'name' => 'Faculty Preference',
                'priority' => 'faculty_preference',
                'weights' => ['balance' => 0.3, 'conflicts' => 0.2, 'preferences' => 0.5]
            ]
        ];
        
        return $strategies[$index] ?? $strategies[0];
    }
    
    private function generateSingleTimetable(array $strategy): array {
        // Clear existing timetable
        clear_timetable();
        
        $schedule = [];
        $conflicts = [];
        $scheduledClasses = 0;
        
        // Initialize schedule grid
        $this->initializeScheduleGrid($schedule);
        
        // NEW APPROACH: Fill all batches fairly using round-robin scheduling
        $batchResult = $this->fillAllBatchesRoundRobin($schedule, $strategy);
        $scheduledClasses = $batchResult['scheduled'];
        $conflicts = $batchResult['conflicts'];
        
        // Save successful schedule to database
        if ($scheduledClasses > 0) {
            $this->saveScheduleToDatabase($schedule);
        }
        
        return [
            'success' => $scheduledClasses > 0,
            'scheduled_classes' => $scheduledClasses,
            'conflicts' => $conflicts,
            'schedule' => $schedule,
            'coverage' => $this->calculateCoverage($schedule),
            'suggestions' => $this->generateSuggestions($conflicts)
        ];
    }
    
    private function initializeScheduleGrid(array &$schedule): void {
        foreach ($this->batches as $batch) {
            $schedule[$batch['id']] = [];
            for ($day = 1; $day <= $this->workingDays; $day++) {
                $schedule[$batch['id']][$day] = array_fill(1, $this->maxPeriodsPerDay, null);
            }
        }
    }
    
    private function fillAllBatchesRoundRobin(array &$schedule, array $strategy): array {
        $totalScheduled = 0;
        $allConflicts = [];
        
        // Fill schedule day by day, period by period, rotating through batches
        for ($day = 1; $day <= $this->workingDays; $day++) {
            for ($period = 1; $period <= $this->requiredClassesPerDay; $period++) {
                foreach ($this->batches as $batch) {
                    $batchId = $batch['id'];
                    
                    // Check if this batch already has a class in this period
                    if (!empty($schedule[$batchId][$day][$period])) {
                        continue;
                    }
                    
                    // Try to schedule a class for this batch at this time
                    $result = $this->scheduleClassForBatch($batchId, $day, $period, $schedule, $strategy);
                    
                    if ($result['success']) {
                        $totalScheduled++;
                    } else {
                        $allConflicts[] = $result['conflict'];
                    }
                }
            }
        }
        
        return [
            'scheduled' => $totalScheduled,
            'conflicts' => $allConflicts
        ];
    }
    
    private function scheduleClassForBatch(int $batchId, int $day, int $period, array &$schedule, array $strategy): array {
        // Get subjects for this batch
        $batchMappings = array_filter($this->mappings, fn($m) => $m['batch_id'] === $batchId);
        
        if (empty($batchMappings)) {
            return [
                'success' => false,
                'conflict' => [
                    'batch_id' => $batchId,
                    'day' => $day,
                    'period' => $period,
                    'message' => 'No subjects assigned to batch'
                ]
            ];
        }
        
        // Create weighted subject pool (subjects with more hours get higher priority)
        $subjectPool = [];
        foreach ($batchMappings as $mapping) {
            $weight = $mapping['weekly_hours'];
            for ($i = 0; $i < $weight; $i++) {
                $subjectPool[] = $mapping;
            }
        }
        
        // Shuffle for variety
        shuffle($subjectPool);
        
        // Try each subject until we find one that can be scheduled
        foreach ($subjectPool as $subject) {
            $facultyId = $subject['faculty_id'];
            
            // Check if faculty is available
            if (!is_faculty_available($facultyId, $day, $period)) {
                continue;
            }
            
            // Check for conflicts
            if ($this->isSlotAvailable($batchId, $facultyId, $day, $period, $schedule)) {
                // Find classroom
                $classroomId = $this->findBestClassroom($day, $period, $schedule);
                
                if ($classroomId) {
                    // Schedule the class
                    $schedule[$batchId][$day][$period] = [
                        'subject_id' => $subject['subject_id'],
                        'faculty_id' => $subject['faculty_id'],
                        'classroom_id' => $classroomId,
                        'mapping_id' => $subject['id']
                    ];
                    
                    return ['success' => true];
                }
            }
        }
        
        // Could not schedule any subject
        $batchCode = '';
        foreach ($this->batches as $batch) {
            if ($batch['id'] == $batchId) {
                $batchCode = $batch['batch_code'];
                break;
            }
        }
        
        return [
            'success' => false,
            'conflict' => [
                'batch_code' => $batchCode,
                'day' => $day,
                'period' => $period,
                'message' => 'No available faculty or classroom for any subject'
            ]
        ];
    }

    private function fillBatchSchedule(int $batchId, array &$schedule, array $strategy): array {
        $scheduled = 0;
        $conflicts = [];
        
        // Get all subjects for this batch
        $batchMappings = array_filter($this->mappings, fn($m) => $m['batch_id'] === $batchId);
        
        if (empty($batchMappings)) {
            return ['scheduled' => 0, 'conflicts' => []];
        }
        
        // Create a subject pool based on weekly hours
        $subjectPool = $this->createSubjectPool($batchMappings);
        
        // Fill each day with exactly 6 classes
        for ($day = 1; $day <= $this->workingDays; $day++) {
            $dayResult = $this->fillDaySchedule($batchId, $day, $subjectPool, $schedule, $strategy);
            $scheduled += $dayResult['scheduled'];
            $conflicts = array_merge($conflicts, $dayResult['conflicts']);
        }
        
        return ['scheduled' => $scheduled, 'conflicts' => $conflicts];
    }
    
    private function createSubjectPool(array $batchMappings): array {
        $pool = [];
        
        foreach ($batchMappings as $mapping) {
            // Add each subject to the pool based on its weekly hours
            for ($i = 0; $i < $mapping['weekly_hours']; $i++) {
                $pool[] = [
                    'subject_id' => $mapping['subject_id'],
                    'faculty_id' => $mapping['faculty_id'],
                    'subject_code' => $mapping['subject_code'],
                    'faculty_code' => $mapping['faculty_code'],
                    'batch_code' => $mapping['batch_code'],
                    'mapping_id' => $mapping['id']
                ];
            }
        }
        
        // Shuffle for better distribution
        shuffle($pool);
        return $pool;
    }
    
    private function fillDaySchedule(int $batchId, int $day, array &$subjectPool, array &$schedule, array $strategy): array {
        $scheduled = 0;
        $conflicts = [];
        
        // Try to schedule exactly 6 classes for this day
        for ($classNum = 1; $classNum <= $this->requiredClassesPerDay; $classNum++) {
            if (empty($subjectPool)) {
                // If we run out of subjects, repeat subjects to fill the day
                $subjectPool = $this->createSubjectPool(
                    array_filter($this->mappings, fn($m) => $m['batch_id'] === $batchId)
                );
                shuffle($subjectPool);
            }
            
            $classScheduled = false;
            $attempts = 0;
            $maxAttempts = min(count($subjectPool), 10);
            
            // Try different subjects until we find one that can be scheduled
            while (!$classScheduled && $attempts < $maxAttempts && !empty($subjectPool)) {
                $subjectIndex = $attempts % count($subjectPool);
                $subject = $subjectPool[$subjectIndex];
                
                // Find the best period for this subject
                $slot = $this->findOptimalSlotForDay($batchId, $subject['faculty_id'], $day, $schedule, $strategy);
                
                if ($slot) {
                    $classroomId = $this->findBestClassroom($day, $slot['period'], $schedule);
                    
                    if ($classroomId) {
                        // Schedule the class
                        $schedule[$batchId][$day][$slot['period']] = [
                            'subject_id' => $subject['subject_id'],
                            'faculty_id' => $subject['faculty_id'],
                            'classroom_id' => $classroomId,
                            'mapping_id' => $subject['mapping_id']
                        ];
                        
                        $scheduled++;
                        $classScheduled = true;
                        
                        // Remove this subject from the pool (or keep it if we need more repetitions)
                        // For now, keep it to allow subject repetition
                    } else {
                        $conflicts[] = [
                            'batch_code' => $subject['batch_code'],
                            'subject_code' => $subject['subject_code'],
                            'faculty_code' => $subject['faculty_code'],
                            'day' => $day,
                            'period' => $slot['period'],
                            'message' => 'No classroom available'
                        ];
                    }
                }
                
                $attempts++;
            }
            
            if (!$classScheduled) {
                $conflicts[] = [
                    'batch_code' => $batchId,
                    'day' => $day,
                    'class_number' => $classNum,
                    'message' => 'Could not schedule class ' . $classNum . ' for this day'
                ];
            }
        }
        
        return ['scheduled' => $scheduled, 'conflicts' => $conflicts];
    }
    
    private function findOptimalSlotForDay(int $batchId, int $facultyId, int $day, array $schedule, array $strategy): ?array {
        $bestSlot = null;
        $bestScore = -1;
        
        // Try periods 1-6 first (main class periods), then 7-8 if needed
        $preferredPeriods = [1, 2, 3, 4, 5, 6, 7, 8];
        
        foreach ($preferredPeriods as $period) {
            if ($this->isSlotAvailable($batchId, $facultyId, $day, $period, $schedule)) {
                $score = $this->calculateSlotScore($batchId, $facultyId, $day, $period, $schedule, $strategy);
                
                // Prefer periods 1-6 over 7-8
                if ($period <= 6) {
                    $score += 1.0;
                }
                
                if ($score > $bestScore) {
                    $bestScore = $score;
                    $bestSlot = ['period' => $period, 'score' => $score];
                }
            }
        }
        
        return $bestSlot;
    }
    
    private function isClassroomBusyInSchedule(int $classroomId, int $day, int $period, array $schedule): bool {
        foreach ($schedule as $batchSchedule) {
            if (isset($batchSchedule[$day][$period]) && 
                !empty($batchSchedule[$day][$period]) && 
                $batchSchedule[$day][$period]['classroom_id'] === $classroomId) {
                return true;
            }
        }
        return false;
    }
    
    private function optimizeMappingOrder(array $mappings, array $strategy): array {
        // Sort mappings based on strategy
        switch ($strategy['priority']) {
            case 'distribute_evenly':
                // Prioritize subjects with more weekly hours
                usort($mappings, fn($a, $b) => $b['weekly_hours'] <=> $a['weekly_hours']);
                break;
                
            case 'avoid_conflicts':
                // Prioritize faculty with fewer total assignments
                usort($mappings, function($a, $b) {
                    $loadA = $this->getFacultyTotalLoad($a['faculty_id']);
                    $loadB = $this->getFacultyTotalLoad($b['faculty_id']);
                    return $loadA <=> $loadB;
                });
                break;
                
            case 'faculty_preference':
                // Prioritize based on faculty availability
                usort($mappings, function($a, $b) {
                    $availA = $this->getFacultyAvailabilityScore($a['faculty_id']);
                    $availB = $this->getFacultyAvailabilityScore($b['faculty_id']);
                    return $availB <=> $availA;
                });
                break;
        }
        
        return $mappings;
    }
    
    private function scheduleMapping(array $mapping, array &$schedule, array $strategy): array {
        $batchId = $mapping['batch_id'];
        $subjectId = $mapping['subject_id'];
        $facultyId = $mapping['faculty_id'];
        $weeklyHours = $mapping['weekly_hours'];
        
        $scheduled = 0;
        $conflicts = [];
        
        // Calculate optimal distribution across days
        $dailyDistribution = $this->calculateDailyDistribution($weeklyHours, $this->workingDays);
        
        foreach ($dailyDistribution as $day => $hoursPerDay) {
            for ($hour = 0; $hour < $hoursPerDay; $hour++) {
                $slot = $this->findOptimalSlot($batchId, $facultyId, $day, $schedule, $strategy);
                
                if ($slot) {
                    $classroomId = $this->findBestClassroom($day, $slot['period'], $schedule);
                    
                    if ($classroomId) {
                        // Schedule the class
                        $schedule[$batchId][$day][$slot['period']] = [
                            'subject_id' => $subjectId,
                            'faculty_id' => $facultyId,
                            'classroom_id' => $classroomId,
                            'mapping_id' => $mapping['id']
                        ];
                        
                        $scheduled++;
                    } else {
                        $conflicts[] = [
                            'batch_code' => $mapping['batch_code'],
                            'subject_code' => $mapping['subject_code'],
                            'faculty_code' => $mapping['faculty_code'],
                            'day' => $day,
                            'message' => 'No classroom available'
                        ];
                    }
                } else {
                    $conflicts[] = [
                        'batch_code' => $mapping['batch_code'],
                        'subject_code' => $mapping['subject_code'],
                        'faculty_code' => $mapping['faculty_code'],
                        'day' => $day,
                        'message' => 'No suitable time slot found'
                    ];
                }
            }
        }
        
        return ['scheduled' => $scheduled, 'conflicts' => $conflicts];
    }
    
    private function calculateDailyDistribution(int $weeklyHours, int $workingDays): array {
        $distribution = array_fill(1, $workingDays, 0);
        
        // Distribute hours as evenly as possible across days
        $baseHours = intval($weeklyHours / $workingDays);
        $extraHours = $weeklyHours % $workingDays;
        
        for ($day = 1; $day <= $workingDays; $day++) {
            $distribution[$day] = $baseHours;
            if ($extraHours > 0) {
                $distribution[$day]++;
                $extraHours--;
            }
        }
        
        return $distribution;
    }
    
    private function findOptimalSlot(int $batchId, int $facultyId, int $day, array $schedule, array $strategy): ?array {
        $bestSlot = null;
        $bestScore = -1;
        
        for ($period = 1; $period <= $this->maxPeriodsPerDay; $period++) {
            if ($this->isSlotAvailable($batchId, $facultyId, $day, $period, $schedule)) {
                $score = $this->calculateSlotScore($batchId, $facultyId, $day, $period, $schedule, $strategy);
                
                if ($score > $bestScore) {
                    $bestScore = $score;
                    $bestSlot = ['period' => $period, 'score' => $score];
                }
            }
        }
        
        return $bestSlot;
    }
    
    private function isSlotAvailable(int $batchId, int $facultyId, int $day, int $period, array $schedule): bool {
        // Check if batch is free
        if (!empty($schedule[$batchId][$day][$period])) {
            return false;
        }
        
        // Check if faculty is free
        foreach ($schedule as $bId => $batchSchedule) {
            if (isset($batchSchedule[$day][$period]) && 
                !empty($batchSchedule[$day][$period]) && 
                $batchSchedule[$day][$period]['faculty_id'] === $facultyId) {
                return false;
            }
        }
        
        // Check faculty availability
        if (!is_faculty_available($facultyId, $day, $period)) {
            return false;
        }
        
        return true;
    }
    
    private function calculateSlotScore(int $batchId, int $facultyId, int $day, int $period, array $schedule, array $strategy): float {
        $score = 0.0;
        
        // Prefer morning slots
        if ($strategy['weights']['preferences'] > 0 && $this->constraints['prefer_morning_slots']) {
            $score += (9 - $period) * 0.1;
        }
        
        // Avoid last period
        if ($strategy['weights']['preferences'] > 0 && $this->constraints['avoid_last_period'] && $period === $this->maxPeriodsPerDay) {
            $score -= 0.5;
        }
        
        // Check for gaps (prefer consecutive slots)
        $gapPenalty = $this->calculateGapPenalty($batchId, $day, $period, $schedule);
        $score -= $gapPenalty * $strategy['weights']['balance'];
        
        // Faculty preference score
        $facultyScore = $this->getFacultyPreferenceScore($facultyId, $day, $period);
        $score += $facultyScore * $strategy['weights']['preferences'];
        
        return $score;
    }
    
    private function calculateGapPenalty(int $batchId, int $day, int $period, array $schedule): float {
        $penalty = 0.0;
        $batchDay = $schedule[$batchId][$day];
        
        // Check for gaps before and after
        $hasClassBefore = false;
        $hasClassAfter = false;
        
        for ($p = 1; $p < $period; $p++) {
            if (!empty($batchDay[$p])) {
                $hasClassBefore = true;
                break;
            }
        }
        
        for ($p = $period + 1; $p <= $this->maxPeriodsPerDay; $p++) {
            if (!empty($batchDay[$p])) {
                $hasClassAfter = true;
                break;
            }
        }
        
        // Penalize if this creates a gap
        if ($hasClassBefore && $hasClassAfter) {
            // Check for gaps
            for ($p = 1; $p < $period; $p++) {
                if (empty($batchDay[$p])) {
                    $penalty += 0.2;
                }
            }
        }
        
        return $penalty;
    }
    
    private function getFacultyPreferenceScore(int $facultyId, int $day, int $period): float {
        // This could be enhanced with actual faculty preferences
        // For now, assume earlier periods are preferred
        return (9 - $period) * 0.1;
    }
    
    private function getFacultyTotalLoad(int $facultyId): int {
        static $cache = [];
        
        if (!isset($cache[$facultyId])) {
            $cache[$facultyId] = array_sum(
                array_map(
                    fn($m) => $m['weekly_hours'],
                    array_filter($this->mappings, fn($m) => $m['faculty_id'] === $facultyId)
                )
            );
        }
        
        return $cache[$facultyId];
    }
    
    private function getFacultyAvailabilityScore(int $facultyId): int {
        $availability = get_faculty_availability($facultyId);
        return array_sum(array_map('count', $availability));
    }
    
    private function findBestClassroom(int $day, int $period, array $schedule = []): ?int {
        foreach ($this->classrooms as $classroom) {
            $classroomId = $classroom['id'];
            
            // Check database conflicts
            if (has_conflict(0, 0, $classroomId, $day, $period)) {
                continue;
            }
            
            // Check in-memory schedule conflicts
            if (!empty($schedule) && $this->isClassroomBusyInSchedule($classroomId, $day, $period, $schedule)) {
                continue;
            }
            
            return $classroomId;
        }
        return null;
    }
    
    private function saveScheduleToDatabase(array $schedule): void {
        $savedCount = 0;
        $errors = [];
        
        foreach ($schedule as $batchId => $batchSchedule) {
            foreach ($batchSchedule as $day => $daySchedule) {
                foreach ($daySchedule as $period => $class) {
                    if ($class) {
                        try {
                            db_query("INSERT INTO timetable (batch_id, subject_id, faculty_id, classroom_id, day_of_week, period_number) 
                                     VALUES (?, ?, ?, ?, ?, ?)", 
                                    "iiiiii", [$batchId, $class['subject_id'], $class['faculty_id'], $class['classroom_id'], $day, $period]);
                            $savedCount++;
                        } catch (Exception $e) {
                            $errors[] = "Batch $batchId, Day $day, Period $period: " . $e->getMessage();
                        }
                    }
                }
            }
        }
        
        // Log results for debugging
        error_log("Saved $savedCount classes to database. Errors: " . count($errors));
        if (!empty($errors) && count($errors) < 10) {
            foreach ($errors as $error) {
                error_log("DB Save Error: $error");
            }
        }
    }
    
    private function calculateTimetableScore(array $schedule): float {
        $score = 0.0;
        $totalSlots = 0;
        $filledSlots = 0;
        $gapPenalty = 0.0;
        
        foreach ($schedule as $batchId => $batchSchedule) {
            foreach ($batchSchedule as $day => $daySchedule) {
                $dayClasses = array_filter($daySchedule, fn($slot) => $slot !== null);
                $filledSlots += count($dayClasses);
                $totalSlots += count($daySchedule);
                
                // Calculate gap penalty for this day
                if (count($dayClasses) > 1) {
                    $periods = array_keys($dayClasses);
                    sort($periods);
                    for ($i = 1; $i < count($periods); $i++) {
                        $gap = $periods[$i] - $periods[$i-1] - 1;
                        $gapPenalty += $gap * 0.1;
                    }
                }
            }
        }
        
        // Base score from coverage
        $coverage = $totalSlots > 0 ? $filledSlots / $totalSlots : 0;
        $score = $coverage * 100;
        
        // Subtract gap penalty
        $score -= $gapPenalty;
        
        return max(0, $score);
    }
    
    private function calculateCoverage(array $schedule): array {
        // New calculation: Each batch needs 6 classes per day × 6 days = 36 classes per week
        $totalRequiredPerBatch = $this->requiredClassesPerDay * $this->workingDays;
        $totalRequired = count($this->batches) * $totalRequiredPerBatch;
        $totalScheduled = 0;
        
        foreach ($schedule as $batchSchedule) {
            foreach ($batchSchedule as $daySchedule) {
                $totalScheduled += count(array_filter($daySchedule, fn($slot) => $slot !== null));
            }
        }
        
        return [
            'total_required' => $totalRequired,
            'total_scheduled' => $totalScheduled,
            'percentage' => $totalRequired > 0 ? ($totalScheduled / $totalRequired) * 100 : 0,
            'classes_per_batch_per_week' => $totalRequiredPerBatch,
            'batches_count' => count($this->batches)
        ];
    }
    
    private function generateSuggestions(array $conflicts): array {
        $suggestions = [];
        
        if (!empty($conflicts)) {
            $suggestions[] = "Consider adding more classrooms to resolve scheduling conflicts";
            $suggestions[] = "Review faculty availability to ensure adequate coverage";
            $suggestions[] = "Consider redistributing subject hours across different days";
            
            // Specific suggestions based on conflict types
            $noClassroomConflicts = array_filter($conflicts, fn($c) => str_contains($c['message'], 'classroom'));
            if (count($noClassroomConflicts) > 0) {
                $suggestions[] = "Add " . count($noClassroomConflicts) . " more classrooms to eliminate classroom conflicts";
            }
        }
        
        return $suggestions;
    }
}

// Enhanced API functions
function generate_optimized_timetables(int $numOptions = 3): array {
    $optimizer = new TimetableOptimizer();
    return $optimizer->generateOptimizedTimetables($numOptions);
}

function get_timetable_analytics(): array {
    $timetable = get_current_timetable();
    
    $analytics = [
        'total_classes' => count($timetable),
        'classes_per_day' => [],
        'faculty_utilization' => [],
        'classroom_utilization' => [],
        'batch_coverage' => []
    ];
    
    // Calculate classes per day
    for ($day = 1; $day <= 5; $day++) {
        $dayClasses = array_filter($timetable, fn($class) => $class['day_of_week'] == $day);
        $analytics['classes_per_day'][$day] = count($dayClasses);
    }
    
    // Calculate faculty utilization
    $stmt = db_query("SELECT f.faculty_code, COUNT(t.id) as classes_assigned, f.max_weekly_load
                     FROM faculty f
                     LEFT JOIN timetable t ON f.id = t.faculty_id
                     GROUP BY f.id");
    $facultyData = db_fetch_all($stmt);
    
    foreach ($facultyData as $faculty) {
        $utilization = $faculty['max_weekly_load'] > 0 ? 
            ($faculty['classes_assigned'] / $faculty['max_weekly_load']) * 100 : 0;
        $analytics['faculty_utilization'][] = [
            'faculty_code' => $faculty['faculty_code'],
            'utilization_percent' => round($utilization, 2),
            'classes_assigned' => $faculty['classes_assigned'],
            'max_load' => $faculty['max_weekly_load']
        ];
    }
    
    return $analytics;
} 