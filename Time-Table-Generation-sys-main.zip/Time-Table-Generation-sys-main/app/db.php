<?php

declare(strict_types=1);

require_once __DIR__ . '/config.php';

function db_connect(): mysqli {
	static $conn = null;
	if ($conn instanceof mysqli) {
		return $conn;
	}
	$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	if ($conn->connect_error) {
		die('Database connection failed: ' . $conn->connect_error);
	}
	$conn->set_charset('utf8mb4');
	return $conn;
}

function db_query(string $sql, string $types = '', array $params = []): mysqli_stmt {
	$conn = db_connect();
	$stmt = $conn->prepare($sql);
	if (!$stmt) {
		die('Failed to prepare statement: ' . $conn->error);
	}
	if ($types !== '' && !empty($params)) {
		$stmt->bind_param($types, ...$params);
	}
	if (!$stmt->execute()) {
		die('Failed to execute statement: ' . $stmt->error);
	}
	return $stmt;
}

function db_fetch_all(mysqli_stmt $stmt): array {
	$result = $stmt->get_result();
	return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

function db_fetch_one(mysqli_stmt $stmt): ?array {
	$result = $stmt->get_result();
	if (!$result) {
		return null;
	}
	$row = $result->fetch_assoc();
	return $row !== null ? $row : null;
}

function db_last_insert_id(): int {
	return db_connect()->insert_id;
} 