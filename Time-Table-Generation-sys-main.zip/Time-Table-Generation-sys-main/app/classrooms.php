<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";

function get_classrooms(): array {
    $stmt = db_query("SELECT * FROM classrooms ORDER BY room_code");
    return db_fetch_all($stmt);
}

function get_classroom(int $id): ?array {
    $stmt = db_query("SELECT * FROM classrooms WHERE id = ?", "i", [$id]);
    return db_fetch_one($stmt);
}

function create_classroom(string $room_code, int $capacity, string $room_type): bool {
    try {
        db_query("INSERT INTO classrooms (room_code, capacity, room_type) VALUES (?, ?, ?)", "sis", [$room_code, $capacity, $room_type]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function update_classroom(int $id, string $room_code, int $capacity, string $room_type): bool {
    try {
        $stmt = db_query("UPDATE classrooms SET room_code = ?, capacity = ?, room_type = ? WHERE id = ?", "sisi", [$room_code, $capacity, $room_type, $id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function delete_classroom(int $id): bool {
    try {
        $stmt = db_query("DELETE FROM classrooms WHERE id = ?", "i", [$id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
} 