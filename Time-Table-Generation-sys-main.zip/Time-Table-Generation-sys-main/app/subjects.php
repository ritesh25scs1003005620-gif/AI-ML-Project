<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";

function get_subjects(): array {
    $stmt = db_query("SELECT * FROM subjects ORDER BY subject_code");
    return db_fetch_all($stmt);
}

function get_subject(int $id): ?array {
    $stmt = db_query("SELECT * FROM subjects WHERE id = ?", "i", [$id]);
    return db_fetch_one($stmt);
}

function create_subject(string $subject_code, string $subject_name, int $weekly_hours): bool {
    try {
        db_query("INSERT INTO subjects (subject_code, subject_name, weekly_hours) VALUES (?, ?, ?)", "ssi", [$subject_code, $subject_name, $weekly_hours]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function update_subject(int $id, string $subject_code, string $subject_name, int $weekly_hours): bool {
    try {
        $stmt = db_query("UPDATE subjects SET subject_code = ?, subject_name = ?, weekly_hours = ? WHERE id = ?", "ssii", [$subject_code, $subject_name, $weekly_hours, $id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function delete_subject(int $id): bool {
    try {
        $stmt = db_query("DELETE FROM subjects WHERE id = ?", "i", [$id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
} 