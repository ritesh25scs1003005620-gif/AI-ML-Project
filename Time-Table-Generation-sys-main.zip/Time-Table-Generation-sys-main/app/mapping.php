<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";

function get_all_mappings(): array {
    $stmt = db_query("SELECT bsf.*, b.batch_code, s.subject_name, s.subject_code, f.full_name as faculty_name, f.faculty_code
                     FROM batch_subject_faculty bsf
                     JOIN batches b ON bsf.batch_id = b.id
                     JOIN subjects s ON bsf.subject_id = s.id
                     JOIN faculty f ON bsf.faculty_id = f.id
                     ORDER BY b.batch_code, s.subject_code");
    return db_fetch_all($stmt);
}

function get_mapping(int $id): ?array {
    $stmt = db_query("SELECT bsf.*, b.batch_code, s.subject_name, s.subject_code, f.full_name as faculty_name, f.faculty_code
                     FROM batch_subject_faculty bsf
                     JOIN batches b ON bsf.batch_id = b.id
                     JOIN subjects s ON bsf.subject_id = s.id
                     JOIN faculty f ON bsf.faculty_id = f.id
                     WHERE bsf.id = ?", "i", [$id]);
    return db_fetch_one($stmt);
}

function create_mapping(int $batch_id, int $subject_id, int $faculty_id, int $weekly_hours): bool {
    try {
        // Check if mapping already exists
        $stmt = db_query("SELECT id FROM batch_subject_faculty WHERE batch_id = ? AND subject_id = ? AND faculty_id = ?", 
                        "iii", [$batch_id, $subject_id, $faculty_id]);
        if (db_fetch_one($stmt)) {
            return false; // Mapping already exists
        }
        
        db_query("INSERT INTO batch_subject_faculty (batch_id, subject_id, faculty_id, weekly_hours) VALUES (?, ?, ?, ?)", 
                "iiii", [$batch_id, $subject_id, $faculty_id, $weekly_hours]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function update_mapping(int $id, int $batch_id, int $subject_id, int $faculty_id, int $weekly_hours): bool {
    try {
        $stmt = db_query("UPDATE batch_subject_faculty SET batch_id = ?, subject_id = ?, faculty_id = ?, weekly_hours = ? WHERE id = ?", 
                         "iiiii", [$batch_id, $subject_id, $faculty_id, $weekly_hours, $id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function delete_mapping(int $id): bool {
    try {
        $stmt = db_query("DELETE FROM batch_subject_faculty WHERE id = ?", "i", [$id]);
        return $stmt->affected_rows > 0;
    } catch (Exception $e) {
        return false;
    }
}

function get_mappings_by_batch(int $batch_id): array {
    $stmt = db_query("SELECT bsf.*, s.subject_name, s.subject_code, f.full_name as faculty_name, f.faculty_code
                     FROM batch_subject_faculty bsf
                     JOIN subjects s ON bsf.subject_id = s.id
                     JOIN faculty f ON bsf.faculty_id = f.id
                     WHERE bsf.batch_id = ?
                     ORDER BY s.subject_code", "i", [$batch_id]);
    return db_fetch_all($stmt);
}

function get_mappings_by_faculty(int $faculty_id): array {
    $stmt = db_query("SELECT bsf.*, b.batch_code, s.subject_name, s.subject_code
                     FROM batch_subject_faculty bsf
                     JOIN batches b ON bsf.batch_id = b.id
                     JOIN subjects s ON bsf.subject_id = s.id
                     WHERE bsf.faculty_id = ?
                     ORDER BY b.batch_code, s.subject_code", "i", [$faculty_id]);
    return db_fetch_all($stmt);
} 