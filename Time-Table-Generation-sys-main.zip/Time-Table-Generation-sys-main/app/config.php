<?php

declare(strict_types=1);

// Database configuration
const DB_HOST = '127.0.0.1';
const DB_NAME = 'smart_timetable';
const DB_USER = 'root';
const DB_PASS = '';

// App configuration
const DISPLAY_ERRORS = true; // set to false in production
const BASE_URL = '/smart-timetable/public'; // adjust based on your folder name

if (DISPLAY_ERRORS) {
	ini_set('display_errors', '1');
	error_reporting(E_ALL);
} else {
	ini_set('display_errors', '0');
}

session_start(); 