<?php

declare(strict_types=1);

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/faculty.php";
require_once __DIR__ . "/mapping.php";

function get_current_timetable(): array {
    $stmt = db_query("SELECT t.*, b.batch_code, s.subject_name, s.subject_code, 
                            f.full_name as faculty_name, f.faculty_code, c.room_code
                     FROM timetable t
                     JOIN batches b ON t.batch_id = b.id
                     JOIN subjects s ON t.subject_id = s.id
                     JOIN faculty f ON t.faculty_id = f.id
                     JOIN classrooms c ON t.classroom_id = c.id
                     ORDER BY b.batch_code, t.day_of_week, t.period_number");
    return db_fetch_all($stmt);
}

function clear_timetable(): bool {
    try {
        db_query("DELETE FROM timetable");
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function generate_timetable(): array {
    // Clear existing timetable
    clear_timetable();
    
    $conflicts = [];
    $scheduled_classes = [];
    
    // Get all mappings (batch-subject-faculty combinations)
    $mappings = get_all_mappings();
    
    // Get all classrooms
    $stmt = db_query("SELECT * FROM classrooms ORDER BY capacity DESC");
    $classrooms = db_fetch_all($stmt);
    
    if (empty($classrooms)) {
        return ['success' => false, 'message' => 'No classrooms available'];
    }
    
    // Process each mapping
    foreach ($mappings as $mapping) {
        $batch_id = $mapping['batch_id'];
        $subject_id = $mapping['subject_id'];
        $faculty_id = $mapping['faculty_id'];
        $weekly_hours = $mapping['weekly_hours'];
        
        $classes_scheduled = 0;
        
        // Try to schedule the required weekly hours
        for ($hour = 0; $hour < $weekly_hours; $hour++) {
            $scheduled = false;
            
            // Try each day (Monday to Friday)
            for ($day = 1; $day <= 5 && !$scheduled; $day++) {
                // Try each period (1 to 8)
                for ($period = 1; $period <= 8 && !$scheduled; $period++) {
                    
                    // Check if faculty is available
                    if (!is_faculty_available($faculty_id, $day, $period)) {
                        continue;
                    }
                    
                    // Check for conflicts
                    if (has_conflict($batch_id, $faculty_id, null, $day, $period)) {
                        continue;
                    }
                    
                    // Find available classroom
                    $classroom_id = find_available_classroom($classrooms, $day, $period);
                    if (!$classroom_id) {
                        continue;
                    }
                    
                    // Schedule the class
                    if (schedule_class($batch_id, $subject_id, $faculty_id, $classroom_id, $day, $period)) {
                        $scheduled_classes[] = [
                            'batch_code' => $mapping['batch_code'],
                            'subject_code' => $mapping['subject_code'],
                            'faculty_code' => $mapping['faculty_code'],
                            'day' => $day,
                            'period' => $period
                        ];
                        $classes_scheduled++;
                        $scheduled = true;
                    }
                }
            }
            
            if (!$scheduled) {
                $conflicts[] = [
                    'batch_code' => $mapping['batch_code'],
                    'subject_code' => $mapping['subject_code'],
                    'faculty_code' => $mapping['faculty_code'],
                    'message' => 'Could not find available slot'
                ];
            }
        }
    }
    
    return [
        'success' => true,
        'scheduled_classes' => count($scheduled_classes),
        'conflicts' => $conflicts,
        'timetable' => get_current_timetable()
    ];
}

function has_conflict(int $batch_id, int $faculty_id, ?int $classroom_id, int $day, int $period): bool {
    // Check batch conflict
    $stmt = db_query("SELECT id FROM timetable WHERE batch_id = ? AND day_of_week = ? AND period_number = ?", 
                    "iii", [$batch_id, $day, $period]);
    if (db_fetch_one($stmt)) {
        return true;
    }
    
    // Check faculty conflict
    $stmt = db_query("SELECT id FROM timetable WHERE faculty_id = ? AND day_of_week = ? AND period_number = ?", 
                    "iii", [$faculty_id, $day, $period]);
    if (db_fetch_one($stmt)) {
        return true;
    }
    
    // Check classroom conflict (if classroom specified)
    if ($classroom_id) {
        $stmt = db_query("SELECT id FROM timetable WHERE classroom_id = ? AND day_of_week = ? AND period_number = ?", 
                        "iii", [$classroom_id, $day, $period]);
        if (db_fetch_one($stmt)) {
            return true;
        }
    }
    
    return false;
}

function find_available_classroom(array $classrooms, int $day, int $period): ?int {
    foreach ($classrooms as $classroom) {
        if (!has_conflict(0, 0, $classroom['id'], $day, $period)) {
            return $classroom['id'];
        }
    }
    return null;
}

function schedule_class(int $batch_id, int $subject_id, int $faculty_id, int $classroom_id, int $day, int $period): bool {
    try {
        db_query("INSERT INTO timetable (batch_id, subject_id, faculty_id, classroom_id, day_of_week, period_number) 
                 VALUES (?, ?, ?, ?, ?, ?)", 
                "iiiiii", [$batch_id, $subject_id, $faculty_id, $classroom_id, $day, $period]);
        return true;
    } catch (Exception $e) {
        return false;
    }
}

function get_timetable_by_batch(int $batch_id): array {
    $stmt = db_query("SELECT t.*, s.subject_name, s.subject_code, 
                            f.full_name as faculty_name, f.faculty_code, c.room_code
                     FROM timetable t
                     JOIN subjects s ON t.subject_id = s.id
                     JOIN faculty f ON t.faculty_id = f.id
                     JOIN classrooms c ON t.classroom_id = c.id
                     WHERE t.batch_id = ?
                     ORDER BY t.day_of_week, t.period_number", "i", [$batch_id]);
    return db_fetch_all($stmt);
}

function get_timetable_by_faculty(int $faculty_id): array {
    $stmt = db_query("SELECT t.*, b.batch_code, s.subject_name, s.subject_code, c.room_code
                     FROM timetable t
                     JOIN batches b ON t.batch_id = b.id
                     JOIN subjects s ON t.subject_id = s.id
                     JOIN classrooms c ON t.classroom_id = c.id
                     WHERE t.faculty_id = ?
                     ORDER BY t.day_of_week, t.period_number", "i", [$faculty_id]);
    return db_fetch_all($stmt);
}

function get_timetable_by_classroom(int $classroom_id): array {
    $stmt = db_query("SELECT t.*, b.batch_code, s.subject_name, s.subject_code, 
                            f.full_name as faculty_name, f.faculty_code
                     FROM timetable t
                     JOIN batches b ON t.batch_id = b.id
                     JOIN subjects s ON t.subject_id = s.id
                     JOIN faculty f ON t.faculty_id = f.id
                     WHERE t.classroom_id = ?
                     ORDER BY t.day_of_week, t.period_number", "i", [$classroom_id]);
    return db_fetch_all($stmt);
}

function export_timetable_csv(): string {
    $timetable = get_current_timetable();
    
    $csv = "Batch,Subject,Faculty,Classroom,Day,Period\n";
    
    $days = ['', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    
    foreach ($timetable as $entry) {
        $day_name = $days[$entry['day_of_week']] ?? 'Unknown';
        $csv .= sprintf("%s,%s,%s,%s,%s,%d\n",
            $entry['batch_code'],
            $entry['subject_code'],
            $entry['faculty_code'],
            $entry['room_code'],
            $day_name,
            $entry['period_number']
        );
    }
    
    return $csv;
} 