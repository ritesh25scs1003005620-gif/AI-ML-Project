<?php

declare(strict_types=1);

require_once __DIR__ . '/db.php';

function login(string $email, string $password): bool {
	$stmt = db_query('SELECT * FROM users WHERE email = ?', 's', [$email]);
	$user = db_fetch_one($stmt);
	if (!$user) {
		return false;
	}
	if (!password_verify($password, $user['password_hash'])) {
		return false;
	}
	$_SESSION['user_id'] = (int)$user['id'];
	return true;
}

function logout(): void {
	$_SESSION = [];
	if (ini_get('session.use_cookies')) {
		$params = session_get_cookie_params();
		setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
	}
	session_destroy();
}

function current_user(): ?array {
	if (!isset($_SESSION['user_id'])) {
		return null;
	}
	$stmt = db_query('SELECT id, email, full_name, role FROM users WHERE id = ?', 'i', [$_SESSION['user_id']]);
	return db_fetch_one($stmt);
}

function enforce_login(): void {
	if (!isset($_SESSION['user_id'])) {
		header('Location: ' . BASE_URL . '/?page=login');
		exit;
	}
} 