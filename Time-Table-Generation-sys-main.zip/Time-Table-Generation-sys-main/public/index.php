<?php

declare(strict_types=1);

require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../app/auth.php';
require_once __DIR__ . '/../app/routes.php';

$route = $_GET['page'] ?? 'dashboard';

// Public routes
if ($route === 'login' || $route === 'logout') {
	if ($route === 'login') {
		require_once __DIR__ . '/../views/login.php';
		exit;
	}
	if ($route === 'logout') {
		logout();
		header('Location: ' . BASE_URL . '/?page=login');
		exit;
	}
}

enforce_login();

// Authenticated routes
echo render_layout(handle_route($route)); 